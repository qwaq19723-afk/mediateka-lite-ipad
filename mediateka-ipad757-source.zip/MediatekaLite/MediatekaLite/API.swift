import Foundation
import Security

final class CookieVault {
    static let shared = CookieVault()
    private let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: Config.bundle, kSecAttrAccount as String: "session"]
    func save() {
        let cookies = (HTTPCookieStorage.shared.cookies(for: Config.base) ?? []).map { cookie -> [String: Any] in
            var properties: [String: Any] = [:]
            cookie.properties?.forEach { properties[$0.key.rawValue] = $0.value }
            return properties
        }
        guard let data = try? PropertyListSerialization.data(fromPropertyList: cookies, format: .binary, options: 0) else { return }
        SecItemDelete(query as CFDictionary)
        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(add as CFDictionary, nil)
    }
    func restore() {
        var read = query; read[kSecReturnData as String] = true
        var value: CFTypeRef?
        guard SecItemCopyMatching(read as CFDictionary, &value) == errSecSuccess, let data = value as? Data,
              let list = (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) as? [[String: Any]] else { return }
        for item in list {
            var properties: [HTTPCookiePropertyKey: Any] = [:]
            item.forEach { properties[HTTPCookiePropertyKey(rawValue: $0.key)] = $0.value }
            if let cookie = HTTPCookie(properties: properties), cookie.expiresDate.map({ $0 > Date() }) ?? true {
                HTTPCookieStorage.shared.setCookie(cookie)
            }
        }
    }
    func clear() {
        SecItemDelete(query as CFDictionary)
        (HTTPCookieStorage.shared.cookies(for: Config.base) ?? []).forEach(HTTPCookieStorage.shared.deleteCookie)
    }
}

final class API: NSObject, URLSessionTaskDelegate {
    static let shared = API()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.default
        config.httpCookieStorage = HTTPCookieStorage.shared
        config.httpShouldSetCookies = true
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 145
        config.httpMaximumConnectionsPerHost = 3
        return URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }()
    // Completion always arrives on the main thread. No bearer keys in source or logs.
    @discardableResult func call(_ path: String, method: String = "GET", body: JSON? = nil,
                                 timeout: TimeInterval = 25, done: @escaping (JSON?, Error?) -> Void) -> URLSessionDataTask? {
        guard let url = Config.mediaURL(path.hasPrefix("/") ? String(path.dropFirst()) : path) else {
            done(nil, failure("Недопустимый адрес сервера.")); return nil
        }
        var request = URLRequest(url: url)
        request.httpMethod = method; request.timeoutInterval = timeout
        Config.requestHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        if let body = body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        }
        if path.contains("/operations") && method == "POST" {
            request.setValue(UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased(), forHTTPHeaderField: "X-Request-ID")
        }
        let task = session.dataTask(with: request) { data, response, error in
            let http = response as? HTTPURLResponse
            let json = data.flatMap { try? JSONSerialization.jsonObject(with: $0) } as? JSON
            let issue = error ?? ((http.map { (200..<300).contains($0.statusCode) } ?? false) ? nil :
                NSError(domain: Config.bundle, code: http?.statusCode ?? 0,
                    userInfo: [NSLocalizedDescriptionKey: string(json?["error"]).isEmpty ? "Сервер временно недоступен." : string(json?["error"])]))
            DispatchQueue.main.async { CookieVault.shared.save(); done(json, issue) }
        }
        task.resume(); return task
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map { Config.trusted($0) } == true ? request : nil)
    }
    static func query(_ text: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed; allowed.remove(charactersIn: "&=+?#")
        return text.addingPercentEncoding(withAllowedCharacters: allowed) ?? ""
    }
}
