import Foundation

enum Config {
    static let base = URL(string: "https://panelfreak.zyxcloud.xyz/mediabot/")!
    static let bundle = "xyz.zyxcloud.mediateka.lite"
    static let origin = "https://panelfreak.zyxcloud.xyz"
    static let requestHeaders = ["User-Agent": "MediatekaLite/0.1.5 iPad iOS10",
        "Origin": origin, "Referer": base.absoluteString,
        "X-Mediateka-Device718": "mobile", "X-Mediateka-Max-Height": "720", "Accept": "application/json"]
    static let maxVideoWidth = 1280
    static let maxVideoHeight = 720
    static let maxFileBytes: Int64 = 8_000_000_000
    static let reserveBytes: Int64 = 512 * 1024 * 1024
    static let simultaneousDownloads = 2
    static let bookmarksChanged = Notification.Name("MediatekaBookmarks757Changed")
    static func trusted(_ url: URL) -> Bool {
        return url.scheme == "https" && url.host == base.host && url.port == nil &&
            url.user == nil && url.password == nil && url.path.hasPrefix(base.path) &&
            !url.pathComponents.contains("..") && !url.pathComponents.contains(".") &&
            !(URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedPath.lowercased().contains("%2f") ?? true) &&
            !url.path.contains("\\")
    }
    static func mediaURL(_ value: String) -> URL? {
        guard let url = URL(string: value, relativeTo: base)?.absoluteURL, trusted(url) else { return nil }
        return url
    }
}

typealias JSON = [String: Any]
func string(_ value: Any?) -> String {
    if let text = value as? String { return text }
    if let number = value as? NSNumber { return number.stringValue }
    return ""
}
func number(_ value: Any?) -> Double {
    let result = (value as? NSNumber)?.doubleValue ?? Double(string(value)) ?? 0
    return result.isFinite && abs(result) < 1e15 ? result : 0
}
func failure(_ text: String) -> NSError { return NSError(domain: Config.bundle, code: 1, userInfo: [NSLocalizedDescriptionKey: text]) }

struct SessionSnapshot {
    let reachable: Bool
    let authenticated: Bool
    let owner: String
    let message: String
    init(_ value: JSON?, error: Error?) {
        if let signedIn = value?["authenticated"] as? Bool {
            reachable = true
            let user = value?["user"] as? JSON ?? [:]
            owner = signedIn ? string(user["id"] ?? user["user_id"]) : ""
            authenticated = signedIn && !owner.isEmpty
            message = authenticated ? "Подключено к Медиатеке." :
                (string(value?["reason"]) == "access" ? "Для этого аккаунта доступ закрыт. Войдите другим аккаунтом." :
                "Интернет доступен. Войдите через Telegram для открытия каталога.")
        } else {
            reachable = false; authenticated = false; owner = ""
            let issue = error as NSError?
            if issue?.domain == NSURLErrorDomain && [-1200, -1201, -1202, -1203, -1204].contains(issue?.code ?? 0) {
                message = "Не удалось проверить защищённое соединение. Проверьте дату и время iPad."
            } else if issue?.domain == NSURLErrorDomain && issue?.code == NSURLErrorNotConnectedToInternet {
                message = "Нет подключения к интернету. Скачанное доступно офлайн."
            } else {
                message = "Нет связи с Медиатекой. Нажмите «Проверить связь»."
            }
        }
    }
}

struct Movie {
    let id: String
    let kind: String
    let title: String
    let year: String
    let overview: String
    let poster: String
    let raw: JSON
    init?(_ json: JSON) {
        let id = string(json["id"] ?? json["tmdb_id"])
        guard !id.isEmpty, id.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return nil }
        self.id = id
        let kind = string(json["kind"] ?? json["media_type"])
        self.kind = kind == "tv" || kind == "series" ? "tv" : "movie"
        title = string(json["title"] ?? json["name"])
        year = string(json["year"])
        overview = string(json["overview"] ?? json["description"] ?? json["plot"])
        poster = string(json["cover"] ?? json["poster"])
        raw = json
    }
    var key: String { return kind + "-" + id }
    var bookmarkPayload: JSON? {
        guard let key = Int(id), key > 0, key < 100000000 else { return nil }
        return ["id": key, "kind": kind, "status": "planned"]
    }
    // Persist display metadata only. Owner-bound choices/tickets are renewed online.
    var display: JSON { return ["id": id, "kind": kind, "title": title, "year": year, "overview": overview, "cover": poster] }
}

enum DownloadDisplay {
    static func isActive(_ row: JSON) -> Bool {
        return ["preparing", "downloading", "verifying"].contains(string(row["state"]))
    }
    static func key(_ movie: Movie, context: String) -> String? {
        let key = movie.key + (context.isEmpty ? "" : "-" + context)
        return key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) == nil ? nil : key
    }
    static func note(_ row: JSON) -> String {
        switch string(row["state"]) {
        case "registering": return "Добавляем в очередь…"
        case "queued":
            if string(row["note"]).hasPrefix("Ожидаем подключения") { return "Ожидает подключения к Медиатеке" }
            if row["queue_position"] != nil { return "В очереди · №\(Int(number(row["queue_position"])))" }
            return "В очереди"
        case "preparing":
            let phase = string(row["phase"])
            let label = phase == "staging" ? "Подготовка на сервере" : phase == "verify" ? "Проверка MP4" : "Подготовка MP4"
            return label + (row["preparation_percent"] == nil ? "…" : " · \(Int(max(0, min(99, number(row["preparation_percent"])))))%")
        case "downloading":
            let bytes = number(row["bytes"]), received = max(0, number(row["received"]))
            let amount = ByteCountFormatter.string(fromByteCount: Int64(received), countStyle: .file)
            guard bytes > 0 else { return "Скачивание · " + amount }
            var text = "\(Int(min(100, received / bytes * 100)))% · " + amount + " / " + ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
            let speed = number(row["speed_bps"])
            if speed > 0 && Date().timeIntervalSince1970 - number(row["speed_at"]) < 15 {
                text += "\n" + ByteCountFormatter.string(fromByteCount: Int64(speed), countStyle: .file) + "/с"
                let seconds = max(0, bytes - received) / speed
                text += seconds >= 60 ? " · ещё ≈\(Int(ceil(seconds / 60))) мин" : " · меньше минуты"
            }
            return text
        case "verifying": return "Проверяем видео на iPad…"
        case "ready":
            if number(row["position"]) > 0 { return "Продолжить с \(Int(number(row["position"]) / 60)) мин" }
            return "Доступно без интернета"
        default: return string(row["note"])
        }
    }
    static func fraction(_ row: JSON) -> Float? {
        if string(row["state"]) == "preparing", row["preparation_percent"] != nil {
            return Float(max(0, min(99, number(row["preparation_percent"]))) / 100)
        }
        if string(row["state"]) == "downloading", number(row["bytes"]) > 0 {
            return Float(max(0, min(1, number(row["received"]) / number(row["bytes"]))))
        }
        return nil
    }
}

enum DownloadQueue {
    static func waiting(_ row: JSON) -> Bool { return ["registering", "queued"].contains(string(row["state"])) }
    static func containsJob(_ row: JSON) -> Bool { return waiting(row) || DownloadDisplay.isActive(row) }
    static func pending(_ rows: [JSON]) -> [JSON] {
        return rows.enumerated().filter { waiting($0.element) }.sorted { left, right in
            let a = number(left.element["queued_at"]), b = number(right.element["queued_at"])
            return a == b ? left.offset < right.offset : a < b
        }.map { $0.element }
    }
    static func next(_ rows: [JSON]) -> String? {
        guard rows.filter(DownloadDisplay.isActive).count < Config.simultaneousDownloads,
            !rows.contains(where: { string($0["state"]) == "preparing" }), let first = pending(rows).first,
            string(first["state"]) == "queued", !string(first["ref"]).isEmpty else { return nil }
        return string(first["key"])
    }
    static func reservedBytes(_ rows: [JSON], excluding key: String) -> Int64 {
        return rows.filter { string($0["state"]) == "downloading" && string($0["key"]) != key }.reduce(Int64(0)) {
            $0 + Int64(max(0, number($1["bytes"]) - number($1["received"])))
        }
    }
    static func connectionFailure(_ error: Error?) -> Bool {
        guard let error = error as NSError? else { return false }
        if error.domain == NSURLErrorDomain { return error.code != NSURLErrorCancelled }
        return error.domain == Config.bundle && [401, 403, 502, 503, 504].contains(error.code)
    }
}

// Keep only the server receipt, never a signed download URL or playable ticket.
enum DownloadReceipt {
    static func from(_ links: JSON) -> JSON? {
        guard links["staged"] as? Bool == true, let url = Config.mediaURL(string(links["download_url"])) else { return nil }
        let parts = url.pathComponents
        guard parts.count >= 4, parts[parts.count - 3] == "staging151" else { return nil }
        return payload(["id": parts[parts.count - 2], "digest": parts[parts.count - 1], "size": links["file_size"] ?? 0])
    }
    static func payload(_ receipt: JSON) -> JSON? {
        let id = string(receipt["id"]), digest = string(receipt["digest"]), bytes = number(receipt["size"])
        guard id.range(of: "^[a-f0-9]{32}$", options: .regularExpression) != nil,
            digest.range(of: "^[a-f0-9]{64}$", options: .regularExpression) != nil,
            bytes > 0, bytes <= Double(Config.maxFileBytes), bytes.rounded() == bytes else { return nil }
        return ["action": "staging_ack", "id": id, "digest": digest, "size": Int64(bytes)]
    }
    static func completed(_ value: JSON?, error: Error?) -> Bool {
        if error == nil { return value?["ok"] as? Bool == true }
        let issue = error as NSError?
        return issue?.domain == Config.bundle && [404, 410].contains(issue?.code ?? 0)
    }
}

enum SourcePreference {
    static func metadata(_ row: JSON) -> [JSON] {
        return [row, row["source558"] as? JSON ?? [:], row["release542"] as? JSON ?? [:]]
    }
    static func capture(_ pattern: String, _ text: String) -> String? {
        guard let expression = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
            let hit = expression.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
            hit.numberOfRanges > 1, let range = Range(hit.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }
    static func text(_ row: JSON) -> String { return metadata(row).map { string($0["title"]) + " " + string($0["note"]) }.joined(separator: " ") }
    static func bytes(_ row: JSON) -> Double {
        for m in metadata(row) {
            for key in ["file_size", "size", "catalog_size561"] { if number(m[key]) > 0 { return number(m[key]) } }
        }
        let text = self.text(row)
        if let amount = capture("([0-9]+(?:[.,][0-9]+)?)\\s*(?:GiB|GB|ГБ|ГиБ)", text),
            let value = Double(amount.replacingOccurrences(of: ",", with: ".")) { return value * 1_000_000_000 }
        if let amount = capture("([0-9]+(?:[.,][0-9]+)?)\\s*(?:MiB|MB|МБ|МиБ)", text),
            let value = Double(amount.replacingOccurrences(of: ",", with: ".")) { return value * 1_000_000 }
        return 0
    }
    static func seeds(_ row: JSON) -> Int {
        for m in metadata(row) {
            for key in ["live_seeds", "seeds", "seeders"] {
                if let value = m[key], !(value is NSNull), let count = Double(string(value)), count.isFinite, count >= 0, count < 1_000_000 { return Int(count) }
            }
        }
        return capture("(?:Сиды|Seeders|Seeds)\\s*[:：]?\\s*([0-9]+)", text(row)).flatMap(Int.init) ?? -1
    }
    static func quality(_ row: JSON) -> Int {
        return metadata(row).contains { number($0["height"]) == 720 || number($0["width"]) == 1280 } ||
            capture("(720[pi]?|1280\\s*[xх×])", text(row)) != nil ? 0 : 1
    }
    static func isRelease(_ row: JSON) -> Bool {
        return row["season"] == nil && row["episode"] == nil && (bytes(row) > 0 || seeds(row) >= 0)
    }
    static func sorted(_ rows: [JSON]) -> [JSON] {
        return rows.enumerated().sorted { left, right in
            let a = left.element, b = right.element
            let aq = quality(a), bq = quality(b); if aq != bq { return aq < bq }
            func availability(_ row: JSON) -> Int { let s = seeds(row); return s >= 10 ? 0 : s > 0 ? 1 : s == -1 ? 2 : 3 }
            let aa = availability(a), ba = availability(b); if aa != ba { return aa < ba }
            let az = bytes(a), bz = bytes(b)
            if (az > 0) != (bz > 0) { return az > 0 }
            if az != bz { return az < bz }
            let sa = seeds(a), sb = seeds(b); if sa != sb { return sa > sb }
            return left.offset < right.offset
        }.map { $0.element }
    }
}

enum CatalogSection {
    static func path(series: Bool, popular: Bool, page: Int) -> String {
        let section = (popular ? "popular-" : "new-") + (series ? "series" : "movies")
        return "api/atv/launcher480?section=" + section + "&page=\(page)"
    }
}

enum BookmarkSnapshot {
    static func rows(_ value: JSON) -> [JSON] {
        if let marks = value["bookmarks272"] as? [JSON] { return marks }
        return (value["items"] as? [JSON] ?? []).filter { string($0["status"]) == "planned" }
    }
}

enum VideoQuality {
    static func dimensionsAllowed(width: Double, height: Double) -> Bool {
        return width.isFinite && height.isFinite && width > 0 && height > 0 &&
            max(width, height) <= Double(Config.maxVideoWidth) && min(width, height) <= Double(Config.maxVideoHeight)
    }
    // Catalogue hints can be missing; the server probe and player enforce the final dimensions.
    static func hintAllowed(_ value: JSON) -> Bool {
        let release = value["release542"] as? JSON ?? [:]
        let candidates = [value, value["source558"] as? JSON ?? [:], release,
            release["source558"] as? JSON ?? [:], value["device_work"] as? JSON ?? [:]]
        for metadata in candidates {
            let width = number(metadata["width"]), height = number(metadata["height"])
            if width > Double(Config.maxVideoWidth) || height > Double(Config.maxVideoHeight) { return false }
            let sourceWidth = number(metadata["source_width"]), sourceHeight = number(metadata["source_height"])
            if sourceWidth > Double(Config.maxVideoWidth) || sourceHeight > Double(Config.maxVideoHeight) { return false }
            let title = string(metadata["title"] ?? metadata["name"]).lowercased()
            if title.range(of: "(?<![a-z0-9])(?:1080[pi]?|1440[pi]?|2160[pi]?|4320[pi]?|4k|8k|uhd)(?![a-z0-9])", options: .regularExpression) != nil { return false }
            if title.range(of: "hevc|x265|h[ ._-]?265", options: .regularExpression) != nil { return false }
            if let match = title.range(of: "[0-9]{2,5}\\s*[xх×]\\s*[0-9]{2,5}", options: .regularExpression) {
                let dimensions = title[match].components(separatedBy: CharacterSet.decimalDigits.inverted).filter { !$0.isEmpty }.compactMap(Double.init)
                if dimensions.count == 2 && !dimensionsAllowed(width: dimensions[0], height: dimensions[1]) { return false }
            }
        }
        return true
    }
}
