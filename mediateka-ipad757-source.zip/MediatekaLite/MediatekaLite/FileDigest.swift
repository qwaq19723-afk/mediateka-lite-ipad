import Foundation
import CommonCrypto

enum FileDigest {
    static func sha256(_ url: URL) -> String? {
        guard let input = InputStream(url: url) else { return nil }
        input.open(); defer { input.close() }
        var context = CC_SHA256_CTX(); CC_SHA256_Init(&context)
        var buffer = [UInt8](repeating: 0, count: 1024 * 1024)
        while true {
            let count = input.read(&buffer, maxLength: buffer.count)
            if count < 0 { return nil }; if count == 0 { break }
            buffer.withUnsafeBytes { bytes in _ = CC_SHA256_Update(&context, bytes.baseAddress, CC_LONG(count)) }
        }
        var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        CC_SHA256_Final(&digest, &context)
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
