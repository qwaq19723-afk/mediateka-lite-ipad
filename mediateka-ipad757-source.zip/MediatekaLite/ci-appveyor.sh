#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
for candidate in /Applications/Xcode*.app; do
  if [[ -d "$candidate/Contents/Developer" ]]; then
    detected="$(DEVELOPER_DIR="$candidate/Contents/Developer" xcodebuild -version | head -n 1)"
    if [[ "$detected" == "Xcode 13.4.1" ]]; then
      export DEVELOPER_DIR="$candidate/Contents/Developer"
      break
    fi
  fi
done
if [[ -z "${DEVELOPER_DIR:-}" ]]; then
  echo 'Xcode 13.4.1 отсутствует в выделенной среде AppVeyor. Нужна проверка доступности старого образа.' >&2
  exit 2
fi
bash build-ios10.sh
