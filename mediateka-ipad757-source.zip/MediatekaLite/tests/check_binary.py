"""Run only on the legacy Mac after a real device build."""
import json
import plistlib
import re
import subprocess
import sys
from pathlib import Path

app=Path(sys.argv[1])
info=plistlib.loads((app/'Info.plist').read_bytes())
assert info['MinimumOSVersion']=='10.0',info.get('MinimumOSVersion')
assert info['UIDeviceFamily']==[2]
binary=app/info['CFBundleExecutable']
commands=subprocess.check_output(['xcrun','otool','-l',str(binary)],text=True)
versions=re.findall(r'\b(?:minos|version)\s+(\d+)\.(\d+)',commands)
assert 'LC_VERSION_MIN_IPHONEOS' in commands or 'LC_BUILD_VERSION' in commands
platforms=re.findall(r'\bplatform\s+(\d+)',commands)
assert not platforms or set(platforms)=={'2'}, 'Expected iOS device binary, not simulator'
minimum=re.search(r'(?:LC_VERSION_MIN_IPHONEOS.*?\bversion|LC_BUILD_VERSION.*?\bminos)\s+(\d+)\.(\d+)',commands,re.S)
assert minimum and tuple(map(int,minimum.groups())) <= (10,0), 'Binary minimum OS exceeds iOS 10'
assert (app/'Frameworks/libswiftCore.dylib').is_file(), 'Swift runtime for iOS 10 must be embedded'
assert not (app/'embedded.mobileprovision').exists(), 'This pipeline intentionally creates an unsigned artifact'
print(json.dumps({'device_binary_verified':True,'minimum_ios':'10.0','architecture':'arm64','signed':False}))
