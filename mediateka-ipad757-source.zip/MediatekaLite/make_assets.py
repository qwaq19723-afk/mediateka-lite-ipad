"""Render the established M brand into required iPad icon sizes (no remote assets)."""
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
root=Path(__file__).resolve().parent/'MediatekaLite/Assets.xcassets'
icons=root/'AppIcon.appiconset';icons.mkdir(parents=True,exist_ok=True)
fonts=[Path('C:/Windows/Fonts/arialbd.ttf'),Path('/System/Library/Fonts/Supplemental/Arial Bold.ttf')]
font=next((p for p in fonts if p.exists()),None)
assert font, 'Arial Bold required only for regenerating icons'
base=Image.new('RGB',(1024,1024),(22,43,62));draw=ImageDraw.Draw(base)
draw.rounded_rectangle((100,100,924,924),radius=170,fill=(45,76,96),outline=(146,219,194),width=24)
f=ImageFont.truetype(str(font),600)
box=draw.textbbox((0,0),'M',font=f)
draw.text(((1024-(box[2]-box[0]))/2,(1024-(box[3]-box[1]))/2-box[1]),'M',font=f,fill=(244,248,250))
rows=[]
for size,scale,idiom in [(20,1,'ipad'),(20,2,'ipad'),(29,1,'ipad'),(29,2,'ipad'),(40,1,'ipad'),(40,2,'ipad'),(76,1,'ipad'),(76,2,'ipad'),(83.5,2,'ipad'),(1024,1,'ios-marketing')]:
    px=int(size*scale);name=f'icon-{px}.png';base.resize((px,px),Image.Resampling.LANCZOS).save(icons/name)
    rows.append({'size':f'{size:g}x{size:g}','idiom':idiom,'scale':f'{scale}x','filename':name})
(root/'Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}}),encoding='utf-8')
(icons/'Contents.json').write_text(json.dumps({'images':rows,'info':{'author':'xcode','version':1}},indent=2),encoding='utf-8')
print('iPad icons generated: '+str(len(rows)))
