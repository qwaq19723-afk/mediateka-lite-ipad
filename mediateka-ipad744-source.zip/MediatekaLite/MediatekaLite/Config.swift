import Foundation

enum Config {
    static let base = URL(string: "https://panelfreak.zyxcloud.xyz/mediabot/")!
    static let bundle = "xyz.zyxcloud.mediateka.lite"
    static let origin = "https://panelfreak.zyxcloud.xyz"
    static let requestHeaders = ["User-Agent": "MediatekaLite/0.1.1 iPad iOS10",
        "Origin": origin, "Referer": base.absoluteString,
        "X-Mediateka-Device718": "mobile", "Accept": "application/json"]
    static let maxFileBytes: Int64 = 12 * 1024 * 1024 * 1024
    static let reserveBytes: Int64 = 512 * 1024 * 1024
    static func trusted(_ url: URL) -> Bool {
        return url.scheme == "https" && url.host == base.host && url.port == nil &&
            url.user == nil && url.password == nil && url.path.hasPrefix(base.path) &&
            !url.pathComponents.contains("..") && !url.pathComponents.contains(".") &&
            !(URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedPath.lowercased().contains("%2f") ?? true) &&
            !url.path.contains("\\")
    }
    static func mediaURL(_ value: String) -> URL? {
        guard let url = URL(string: value, relativeTo: base)?.absoluteURL, trusted(url) else { return nil }
        return url
    }
}

typealias JSON = [String: Any]
func string(_ value: Any?) -> String {
    if let text = value as? String { return text }
    if let number = value as? NSNumber { return number.stringValue }
    return ""
}
func number(_ value: Any?) -> Double {
    let result = (value as? NSNumber)?.doubleValue ?? Double(string(value)) ?? 0
    return result.isFinite && abs(result) < 1e15 ? result : 0
}
func failure(_ text: String) -> NSError { return NSError(domain: Config.bundle, code: 1, userInfo: [NSLocalizedDescriptionKey: text]) }

struct SessionSnapshot {
    let reachable: Bool
    let authenticated: Bool
    let owner: String
    let message: String
    init(_ value: JSON?, error: Error?) {
        if let signedIn = value?["authenticated"] as? Bool {
            reachable = true
            let user = value?["user"] as? JSON ?? [:]
            owner = signedIn ? string(user["id"] ?? user["user_id"]) : ""
            authenticated = signedIn && !owner.isEmpty
            message = authenticated ? "Подключено к Медиатеке." :
                (string(value?["reason"]) == "access" ? "Для этого аккаунта доступ закрыт. Войдите другим аккаунтом." :
                "Интернет доступен. Войдите через Telegram для открытия каталога.")
        } else {
            reachable = false; authenticated = false; owner = ""
            let issue = error as NSError?
            if issue?.domain == NSURLErrorDomain && [-1200, -1201, -1202, -1203, -1204].contains(issue?.code ?? 0) {
                message = "Не удалось проверить защищённое соединение. Проверьте дату и время iPad."
            } else if issue?.domain == NSURLErrorDomain && issue?.code == NSURLErrorNotConnectedToInternet {
                message = "Нет подключения к интернету. Скачанное доступно офлайн."
            } else {
                message = "Нет связи с Медиатекой. Нажмите «Проверить связь»."
            }
        }
    }
}

struct Movie {
    let id: String
    let kind: String
    let title: String
    let year: String
    let overview: String
    let poster: String
    let raw: JSON
    init?(_ json: JSON) {
        let id = string(json["id"] ?? json["tmdb_id"])
        guard !id.isEmpty, id.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return nil }
        self.id = id
        let kind = string(json["kind"] ?? json["media_type"])
        self.kind = kind == "tv" || kind == "series" ? "tv" : "movie"
        title = string(json["title"] ?? json["name"])
        year = string(json["year"])
        overview = string(json["overview"] ?? json["description"] ?? json["plot"])
        poster = string(json["cover"] ?? json["poster"])
        raw = json
    }
    var key: String { return kind + "-" + id }
    // Persist display metadata only. Owner-bound choices/tickets are renewed online.
    var display: JSON { return ["id": id, "kind": kind, "title": title, "year": year, "overview": overview, "cover": poster] }
}
