import Foundation

var checks = 0
func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
    checks += 1
    if !condition() { fputs("FAILED: " + message + "\n", stderr); exit(1) }
}
expect(Config.mediaURL("api/session")?.path == "/mediabot/api/session", "relative API origin")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/mediabot/file.mp4") != nil, "same origin file")
expect(Config.mediaURL("http://panelfreak.zyxcloud.xyz/mediabot/file.mp4") == nil, "TLS required")
expect(Config.mediaURL("https://elsewhere.invalid/mediabot/file.mp4") == nil, "foreign origin denied")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/admin/") == nil, "outside application denied")
expect(Config.mediaURL("https://name:secret@panelfreak.zyxcloud.xyz/mediabot/file") == nil, "userinfo denied")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/mediabot/%2e%2e/private") == nil, "encoded traversal denied")
expect(Movie(["id":"../../bad","kind":"movie"]) == nil, "invalid identity denied")
let movie = Movie(["id":238,"kind":"movie","title":"Крёстный отец","year":1972,
    "choice":"PRIVATE","torrent_ticket":"PRIVATE","stream_url":"PRIVATE","cover":"poster.jpg"])!
expect(movie.key == "movie-238", "stable movie identity")
expect(movie.display["choice"] == nil && movie.display["torrent_ticket"] == nil && movie.display["stream_url"] == nil, "no playable credentials in cached metadata")
expect(Movie(["id":1,"media_type":"series"])?.kind == "tv", "series identity")
expect(movie.title == "Крёстный отец" && movie.year == "1972", "Russian text and number normalization")
expect(Config.requestHeaders["Origin"] == "https://panelfreak.zyxcloud.xyz", "device login requires explicit same-origin header")
expect(Config.requestHeaders["Referer"] == Config.base.absoluteString, "native requests identify application root")
let signedOut = SessionSnapshot(["authenticated":false,"reason":"session"], error:NSError(domain:Config.bundle,code:401))
expect(signedOut.reachable && !signedOut.authenticated, "HTTP401 means server reachable, sign-in needed")
expect(signedOut.message.contains("Telegram"), "signed-out state explains sign-in")
let signedIn = SessionSnapshot(["authenticated":true,"user":["id":123]],error:nil)
expect(signedIn.reachable && signedIn.authenticated && signedIn.owner=="123", "authenticated owner parsed")
expect(!SessionSnapshot(["authenticated":true],error:nil).authenticated, "missing owner is not authorized")
let blocked = SessionSnapshot(["authenticated":false,"reason":"access"],error:NSError(domain:Config.bundle,code:403))
expect(blocked.reachable && blocked.message.contains("доступ закрыт"), "access denial is not an Internet failure")
let disconnected = SessionSnapshot(nil,error:NSError(domain:NSURLErrorDomain,code:NSURLErrorNotConnectedToInternet))
expect(!disconnected.reachable && disconnected.message.contains("Нет подключения"), "offline transport state")
let tlsError = SessionSnapshot(nil,error:NSError(domain:NSURLErrorDomain,code:-1202))
expect(!tlsError.reachable && tlsError.message.contains("защищённое"), "certificate failure explained without bypass")
expect(!SessionSnapshot(["unexpected":true],error:nil).reachable, "invalid session response does not silently sign in")
print("Model checks passed: \(checks)")
