"""Windows-compatible packaging checks. NOT a Swift compiler or device test."""
import json
import plistlib
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
APP=ROOT/'MediatekaLite'
for shell in ROOT.glob('*.sh'):
    assert b'\r' not in shell.read_bytes(), 'Build shell scripts require LF line endings: '+shell.name
info=plistlib.loads((APP/'Info.plist').read_bytes())
assert info['MinimumOSVersion']=='10.0'
assert info['UIDeviceFamily']==[2]
assert info['UIRequiredDeviceCapabilities']==['arm64']
assert info['NSAppTransportSecurity']=={'NSAllowsArbitraryLoads':False}
assert len(info['UISupportedInterfaceOrientations~ipad'])==4
assert not (ROOT/'Package.swift').exists(), 'No accidental modern Swift package requirements'
pbx=(ROOT/'MediatekaLite.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
assert 'objectVersion = 54' in pbx
identifiers=re.findall(r'^([A-F0-9]{24}) = ',pbx,re.M)
assert len(identifiers)==len(set(identifiers))
for path in APP.glob('*.swift'):
    assert path.name in pbx, path.name
    source=path.read_text(encoding='utf-8')
    for forbidden in ('import SwiftUI','NavigationStack','systemName:', '.safeAreaLayoutGuide','URLSession.shared.data(for:', 'Task {', 'async throws','overrideUserInterfaceStyle'):
        assert forbidden not in source, (path.name,forbidden)
ET.parse(APP/'LaunchScreen.storyboard')
ET.parse(ROOT/'MediatekaLite.xcodeproj/xcshareddata/xcschemes/MediatekaLite.xcscheme')
assets=APP/'Assets.xcassets/AppIcon.appiconset'
icons=json.loads((assets/'Contents.json').read_text())
assert any(row.get('size')=='76x76' and row.get('scale')=='2x' for row in icons['images'])
for row in icons['images']: assert (assets/row['filename']).is_file()
assert 'self-hosted' in (ROOT/'.github/workflows/ios10.yml').read_text(encoding='utf-8')
print(json.dumps({'packaging_checks':'passed','swift_compiled':False,'physical_device_tested':False,
                  'minimum_ios':'10.0','native_sources':len(list(APP.glob('*.swift'))),'device':'iPad mini 2 Retina'},ensure_ascii=False))
