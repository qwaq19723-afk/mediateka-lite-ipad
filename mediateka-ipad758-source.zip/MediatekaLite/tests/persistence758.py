"""Execute the actual read/save/file methods against disposable sandbox fixtures."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'MediatekaLite/OfflineStore.swift').read_text()
def method(start,end): return s[s.index(start):s.index(end,s.index(start))].replace('private func','func')
methods=method('    private func read()', '    private func scheduleQueue()')+method('    func file(', '    func remove(')
prefix='''import Foundation
final class OfflineStore {
    let manager = FileManager.default
    let root: URL
    var owner = "123"
    var rows: [JSON] = []
    var indexWritable = false
    var storageIssue: String?
    var connectionBlocked = false
    var directory: URL { return root.appendingPathComponent(owner) }
    init(_ root: URL) { self.root = root }
    func scheduleQueue() {}
    func scheduleRecovery() {}
    static let changed = Notification.Name("fixture")
'''
tests='''
var passed = 0
func check(_ condition: @autoclosure () -> Bool, _ name: String) {
    guard condition() else { fatalError("Persistence failed: " + name) }; passed += 1
}
let fm = FileManager.default
let root = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
try fm.createDirectory(at: root, withIntermediateDirectories: true)
defer { try? fm.removeItem(at: root) }
let store = OfflineStore(root)
store.read(); check(store.indexWritable, "new store writable")
store.rows = [["key":"movie-42", "state":"ready", "bytes":4,
               "movie":["id":"42","title":"Fixture"]]]
try fm.createDirectory(at: store.directory, withIntermediateDirectories: true)
try Data([1,2,3,4]).write(to: store.directory.appendingPathComponent("movie-42.mp4"))
store.save()
check(store.storageIssue == nil, "saved")
check(fm.fileExists(atPath: store.directory.appendingPathComponent("movie-42.entry.json").path), "per-item record")
check(fm.fileExists(atPath: root.appendingPathComponent("last-owner.json").path), "owner marker")
let again = OfflineStore(root); again.read()
check(again.rows.count == 1, "relaunch rows")
check(string(again.rows[0]["state"]) == "ready", "relaunch ready")
again.save()
let primary = store.directory.appendingPathComponent("index.json")
try Data("broken".utf8).write(to: primary)
let backup = OfflineStore(root); backup.read()
check(backup.rows.count == 1 && backup.indexWritable, "corrupt primary recovered")
try fm.removeItem(at: store.directory.appendingPathComponent("index.backup.json"))
let sidecar = OfflineStore(root); sidecar.read()
check(sidecar.rows.count == 1, "sidecar without backup")
check(sidecar.file(sidecar.rows[0]) != nil, "recovered video usable")
try Data().write(to: store.directory.appendingPathComponent("movie-42.deleted"))
let deleted = OfflineStore(root); deleted.read()
check(deleted.rows.isEmpty, "deleted row not resurrected")
try fm.removeItem(at: store.directory.appendingPathComponent("movie-42.deleted"))
try Data("broken".utf8).write(to: store.directory.appendingPathComponent("movie-42.entry.json"))
let blocked = OfflineStore(root); blocked.read()
check(!blocked.indexWritable && blocked.storageIssue != nil, "unreadable indices block writes")
blocked.save()
check(try Data(contentsOf: primary) == Data("broken".utf8), "no empty overwrite")
check(fm.fileExists(atPath: store.directory.appendingPathComponent("movie-42.mp4").path), "orphan video preserved")
let foreign = OfflineStore(root); foreign.owner = "999"; foreign.read()
check(foreign.rows.isEmpty, "other owner isolated")
let foreignEntry = try JSONSerialization.data(withJSONObject:["owner":"999", "item":["key":"movie-42"]])
try foreignEntry.write(to: store.directory.appendingPathComponent("movie-42.entry.json"))
let wrong = OfflineStore(root); wrong.read()
check(wrong.rows.isEmpty && !wrong.indexWritable, "foreign sidecar rejected")
print("Persistence checks passed: \\(passed)")
'''
# Swift autoclosures cannot throw; perform throwing reads before assertions.
tests=tests.replace('check(try Data(contentsOf: primary) == Data("broken".utf8),', 'let protectedData = try Data(contentsOf: primary)\ncheck(protectedData == Data("broken".utf8),')
out=r/'build/persistence';out.mkdir(parents=True,exist_ok=True)
(out/'main.swift').write_text(prefix+methods+'}\n'+tests)
print('Actual persistence methods extracted for isolated filesystem tests.')
