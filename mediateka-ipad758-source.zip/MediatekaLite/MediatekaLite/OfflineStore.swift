import Foundation
import AVFoundation
import CoreMedia
import UIKit
import ImageIO
import AudioToolbox

final class OfflineStore: NSObject, URLSessionDownloadDelegate {
    static let shared = OfflineStore()
    static let changed = Notification.Name("OfflineChanged740")
    private(set) var owner = UserDefaults.standard.string(forKey: "lastOwner740") ?? ""
    private(set) var rows: [JSON] = []
    var backgroundCompletion: (() -> Void)?
    private var lastSave = Date.distantPast
    private var preparations: [String: UUID] = [:]
    private var preparationRequests: [String: URLSessionDataTask] = [:]
    private var reconciliation: UUID?
    private var pumpScheduled = false
    private var connectionBlocked = false
    private var recoveryScheduled = false
    private var acknowledgements: [String: UUID] = [:]
    private var acknowledgementRequests: [String: URLSessionDataTask] = [:]
    private var acknowledgementRetryScheduled = false
    private var transferSamples: [String: (Date, Int64)] = [:]
    private var indexWritable = false
    private(set) var storageIssue: String?
    private var posterRequests: Set<String> = []
    private var posterRetryAt: [String: Date] = [:]
    private let manager = FileManager.default
    private lazy var root: URL = {
        let base = manager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Offline740", isDirectory: true)
        try? manager.createDirectory(at: base, withIntermediateDirectories: true)
        var folder = base; var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? folder.setResourceValues(values)
        return folder
    }()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Config.bundle + ".downloads")
        config.httpCookieStorage = HTTPCookieStorage.shared; config.httpShouldSetCookies = true
        config.httpMaximumConnectionsPerHost = Config.simultaneousDownloads; config.allowsCellularAccess = false
        config.isDiscretionary = false; config.sessionSendsLaunchEvents = true
        return URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue.main)
    }()
    private var directory: URL { return root.appendingPathComponent(owner.isEmpty ? "none" : owner, isDirectory: true) }
    override init() {
        super.init()
        if owner.isEmpty, let data = try? Data(contentsOf: root.appendingPathComponent("last-owner.json")),
            let marker = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
            let previous = marker["owner"] as? String, previous.range(of: "^[0-9]+$", options: .regularExpression) != nil {
            owner = previous; UserDefaults.standard.set(previous, forKey: "lastOwner740")
        }
        read()
    }
    func activate() {
        if !indexWritable { read() }
        let scope = owner
        let snapshot = rows
        let token = UUID(); reconciliation = token
        if AppDelegate.current.authenticated && AppDelegate.current.serverReachable { connectionBlocked = false }
        session.getAllTasks { tasks in DispatchQueue.main.async {
            guard self.owner == scope, self.reconciliation == token else { return }
            let active = Set(tasks.compactMap { $0.taskDescription })
            for index in self.rows.indices where string(self.rows[index]["state"]) == "downloading" {
                let key = string(self.rows[index]["key"])
                guard snapshot.contains(where: { string($0["key"]) == key && string($0["state"]) == "downloading" &&
                    string($0["task_id"]) == string(self.rows[index]["task_id"]) }) else { continue }
                if !active.contains(self.owner + "|" + string(self.rows[index]["key"])) {
                    self.rows[index]["state"] = "paused"; self.rows[index]["note"] = "Продолжите загрузку."
                }
            }
            for i in self.rows.indices where string(self.rows[i]["state"]) == "preparing" {
                let key = string(self.rows[i]["key"])
                if self.preparations[key] == nil && !string(self.rows[i]["ref"]).isEmpty {
                    self.rows[i]["state"] = "queued"; self.rows[i]["note"] = "Продолжим подготовку по очереди."
                }
            }
            self.reconciliation = nil
            self.save()
            self.acknowledgeReadyFiles()
            self.repairPosters()
        }}
    }
    func switchOwner(_ value: String) {
        guard value.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return }
        if owner != value {
            preparationRequests.values.forEach { $0.cancel() }
            preparationRequests.removeAll(); preparations.removeAll()
            acknowledgementRequests.values.forEach { $0.cancel() }; acknowledgementRequests.removeAll()
            acknowledgements.removeAll(); transferSamples.removeAll()
            reconciliation = nil; connectionBlocked = false
            let previous = owner + "|"
            session.getAllTasks { tasks in tasks.filter { $0.taskDescription?.hasPrefix(previous) == true }.forEach { $0.cancel() } }
            owner = value; UserDefaults.standard.set(value, forKey: "lastOwner740"); read(); save()
        }
        activate()
    }
    private func read() {
        indexWritable = false; storageIssue = nil
        guard owner.isEmpty || owner.range(of: "^[0-9]+$", options: .regularExpression) != nil else { owner = ""; rows = []; return }
        func snapshot(_ name: String) -> [JSON]? {
            guard let data = try? Data(contentsOf: directory.appendingPathComponent(name)),
                let value = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
                string(value["owner"]) == owner, number(value["schema"]) == 1,
                let list = value["items"] as? [JSON] else { return nil }
            return list
        }
        let primary = snapshot("index.json")
        var list = primary ?? snapshot("index.backup.json")
        if primary == nil {
            let listing = try? manager.contentsOfDirectory(atPath: directory.path)
            let names = listing ?? []
            var recovered = list ?? []
            for name in names where name.hasSuffix(".entry.json") {
                guard let data = try? Data(contentsOf: directory.appendingPathComponent(name)),
                    let value = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
                    string(value["owner"]) == owner, let row = value["item"] as? JSON,
                    name == string(row["key"]) + ".entry.json" else { continue }
                if let i = recovered.firstIndex(where: { string($0["key"]) == string(row["key"]) }) { recovered[i] = row }
                else { recovered.append(row) }
                if list == nil { list = [] }
            }
            if list != nil { list = recovered }
            else if names.isEmpty && (listing != nil || !manager.fileExists(atPath: directory.path)) { list = [] }
            else {
                storageIssue = "Не удалось прочитать список загрузок. Сохранённые файлы не удалены; запись списка заблокирована."
                rows = []; return
            }
        }
        guard let entries = list else { rows = []; return }
        indexWritable = true
        rows = entries.filter { row in
            let key = string(row["key"])
            return key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil &&
                !manager.fileExists(atPath: directory.appendingPathComponent(key + ".deleted").path)
        }
        for i in rows.indices where string(rows[i]["state"]) == "ready" {
            if file(rows[i]) == nil { rows[i]["state"] = "error"; rows[i]["note"] = "Файл отсутствует или повреждён." }
        }
        for i in rows.indices where ["verifying", "registering"].contains(string(rows[i]["state"])) ||
            (["preparing", "queued"].contains(string(rows[i]["state"])) && string(rows[i]["ref"]).isEmpty) {
            rows[i]["state"] = "paused"; rows[i]["note"] = "Подготовка прервана. Можно повторить."
        }
    }
    private func save() {
        guard !owner.isEmpty, indexWritable else { return }
        do {
            try manager.createDirectory(at: directory, withIntermediateDirectories: true)
            let index = directory.appendingPathComponent("index.json")
            if let previous = try? Data(contentsOf: index),
                let value = (try? JSONSerialization.jsonObject(with: previous)) as? JSON,
                string(value["owner"]) == owner, number(value["schema"]) == 1, value["items"] is [JSON] {
                try previous.write(to: directory.appendingPathComponent("index.backup.json"), options: .atomic)
            }
            for row in rows {
                let key = string(row["key"])
                guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { continue }
                let data = try JSONSerialization.data(withJSONObject: ["owner": owner, "item": row])
                try data.write(to: directory.appendingPathComponent(key + ".entry.json"), options: .atomic)
            }
            let data = try JSONSerialization.data(withJSONObject: ["schema": 1, "owner": owner, "items": rows])
            try data.write(to: index, options: .atomic)
            let marker = try JSONSerialization.data(withJSONObject: ["owner": owner])
            try marker.write(to: root.appendingPathComponent("last-owner.json"), options: .atomic)
            storageIssue = nil
        } catch {
            storageIssue = "Не удалось сохранить список загрузок. Проверьте свободное место на iPad."
        }
        NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
        scheduleQueue()
        if connectionBlocked { scheduleRecovery() }
    }
    private func scheduleQueue() {
        guard !pumpScheduled else { return }; pumpScheduled = true
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }; self.pumpScheduled = false
            self.startNext()
        }
    }
    private func startNext() {
        guard !owner.isEmpty, !connectionBlocked, reconciliation == nil,
            AppDelegate.current.authenticated, UIApplication.shared.applicationState == .active,
            let key = DownloadQueue.next(rows), let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        let token = UUID(); preparations[key] = token
        let retry = rows[i]["queued_retry"] as? Bool ?? false
        rows[i].removeValue(forKey: "queued_retry")
        rows[i]["state"] = "preparing"; rows[i]["note"] = "Проверяем подготовку на сервере…"
        save()
        resolve(key, token: token, scope: owner, until: Date().addingTimeInterval(4 * 3600), retry: retry)
    }
    private func scheduleRecovery() {
        guard !recoveryScheduled, !owner.isEmpty, rows.contains(where: DownloadQueue.waiting) else { return }
        recoveryScheduled = true; let scope = owner
        DispatchQueue.main.asyncAfter(deadline: .now() + 15) { [weak self] in
            guard let self = self else { return }; self.recoveryScheduled = false
            guard self.owner == scope else { if self.connectionBlocked { self.scheduleRecovery() }; return }
            guard self.connectionBlocked, self.rows.contains(where: DownloadQueue.waiting) else { return }
            if UIApplication.shared.applicationState == .active { AppDelegate.current.checkSession() }
            self.scheduleRecovery()
        }
    }
    func file(_ row: JSON) -> URL? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        let url = directory.appendingPathComponent(key + ".mp4")
        guard let attrs = try? manager.attributesOfItem(atPath: url.path),
            let size = attrs[.size] as? NSNumber, size.int64Value > 0,
            size.int64Value == (row["bytes"] as? NSNumber)?.int64Value else { return nil }
        return url
    }
    func remove(_ key: String) {
        guard let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        // A backup must not resurrect a deliberately deleted download.
        do { try Data().write(to: directory.appendingPathComponent(key + ".deleted"), options: .atomic) }
        catch { storageIssue = "Не удалось сохранить удаление. Повторите позже."; return }
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".entry.json"))
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
        acknowledgements.removeValue(forKey: key); acknowledgementRequests.removeValue(forKey: key)?.cancel()
        transferSamples.removeValue(forKey: key)
        let scope = owner
        let taskID = rows[i]["task_id"]
        session.getAllTasks { tasks in tasks.filter { $0.taskDescription == scope + "|" + key &&
            (taskID == nil || $0.taskIdentifier == Int(number(taskID))) }.forEach { $0.cancel() } }
        let url = directory.appendingPathComponent(key + ".mp4")
        try? manager.removeItem(at: url); try? manager.removeItem(at: directory.appendingPathComponent(key + ".resume"))
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".jpg"))
        if owner == scope { rows.remove(at: i); save() }
    }
    func position(_ key: String, seconds: Double) {
        guard seconds.isFinite, let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        rows[i]["position"] = max(0, seconds); save()
    }
    func pause(_ key: String) {
        if let i = rows.firstIndex(where: { string($0["key"]) == key && ["preparing", "registering", "queued"].contains(string($0["state"])) }) {
            preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
            rows[i]["state"] = "paused"; rows[i]["note"] = "Ожидание приостановлено. Можно продолжить."; save(); return
        }
        let scope = owner; let folder = directory
        session.getAllTasks { tasks in
            for task in tasks where task.taskDescription == scope + "|" + key {
                (task as? URLSessionDownloadTask)?.cancel(byProducingResumeData: { data in DispatchQueue.main.async {
                    guard self.owner == scope, let i = self.rows.firstIndex(where: { string($0["key"]) == key &&
                        ["downloading", "paused"].contains(string($0["state"])) &&
                        ($0["task_id"] == nil || Int(number($0["task_id"])) == task.taskIdentifier) }) else { return }
                    if let data = data { try? data.write(to: folder.appendingPathComponent(key + ".resume"), options: .atomic) }
                    self.rows[i]["state"] = "paused"; self.rows[i]["note"] = "Приостановлено"; self.save()
                }})
            }
        }
    }
    func prepare(_ movie: Movie, choice: String, context: String) throws {
        guard indexWritable else { throw failure(storageIssue ?? "Список загрузок временно недоступен.") }
        guard !owner.isEmpty, AppDelegate.current.authenticated, !choice.isEmpty,
            let key = DownloadDisplay.key(movie, context: context) else { throw failure("Для загрузки нужен вход и выбранная серия.") }
        if let old = rows.first(where: { string($0["key"]) == key }),
            DownloadQueue.containsJob(old) || string(old["state"]) == "ready" { throw failure("Этот файл уже есть в загрузках.") }
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
        let i: Int
        if let old = rows.firstIndex(where: { string($0["key"]) == key }) { i = old }
        else { rows.append(["key": key]); i = rows.count - 1 }
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".deleted"))
        rows[i]["movie"] = movie.display; rows[i]["context"] = context; rows[i]["state"] = "registering"
        rows[i]["queued_at"] = Date().timeIntervalSince1970; rows[i].removeValue(forKey: "queued_retry")
        // A newly selected source must never resume bytes from the previous source.
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".resume"))
        rows[i].removeValue(forKey: "ref"); rows[i].removeValue(forKey: "preparation_percent")
        rows[i]["phase"] = "register"; rows[i]["note"] = "Ставим в очередь подготовки…"
        let token = UUID(), scope = owner; preparations[key] = token
        savePoster(movie, key: key); save()
        preparationRequests[key] = API.shared.call("api/device-queue", method: "POST", body: ["action": "register", "choice": choice,
            "download_mode": "compatible", "capabilities": []]) { [weak self] value, error in
            guard let self = self, let current = self.preparationIndex(key, token: token, scope: scope) else { return }
            self.preparationRequests.removeValue(forKey: key)
            if let error = error { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription, error: error); return }
            let ref = string(value?["ref"])
            guard !ref.isEmpty else { self.preparationFailed(key, token: token, scope: scope, note: "Не удалось создать загрузку."); return }
            self.rows[current]["ref"] = ref; self.rows[current]["state"] = "queued"; self.rows[current]["note"] = "В очереди"
            self.preparations.removeValue(forKey: key); self.save()
        }
    }
    private func preparationIndex(_ key: String, token: UUID, scope: String) -> Int? {
        guard owner == scope, preparations[key] == token else { return nil }
        return rows.firstIndex { string($0["key"]) == key && ["preparing", "registering"].contains(string($0["state"])) }
    }
    private func preparationFailed(_ key: String, token: UUID, scope: String, note: String, error: Error? = nil) {
        guard let i = preparationIndex(key, token: token, scope: scope) else { return }
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)
        if DownloadQueue.connectionFailure(error) {
            connectionBlocked = true
            rows[i]["state"] = string(rows[i]["ref"]).isEmpty ? "paused" : "queued"
            rows[i]["note"] = "Ожидаем подключения к Медиатеке. " + note
        } else { rows[i]["state"] = "paused"; rows[i]["note"] = note + " Можно продолжить." }
        save()
    }
    func resumePreparation(_ key: String) throws {
        guard AppDelegate.current.authenticated, let i = rows.firstIndex(where: { string($0["key"]) == key }),
            !string(rows[i]["ref"]).isEmpty else { throw failure("Для продолжения нужен интернет и вход в Медиатеку.") }
        guard !DownloadQueue.containsJob(rows[i]), string(rows[i]["state"]) != "ready" else { return }
        rows[i]["state"] = "queued"; rows[i]["note"] = "В очереди"
        rows[i]["queued_at"] = Date().timeIntervalSince1970; rows[i]["queued_retry"] = true; save()
    }
    private func resolve(_ key: String, token: UUID, scope: String, until: Date, retry: Bool = false) {
        guard let i = preparationIndex(key, token: token, scope: scope) else { return }
        guard Date() < until else { preparationFailed(key, token: token, scope: scope, note: "Подготовка заняла слишком много времени."); return }
        // Preparation belongs to the store, not a screen. Resume polling when the app is foregrounded.
        if UIApplication.shared.applicationState != .active {
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in self?.resolve(key, token: token, scope: scope, until: until, retry: retry) }; return
        }
        preparationRequests[key] = API.shared.call("api/device-queue", method: "POST", body: ["action": "resolve", "ref": string(rows[i]["ref"]),
            "retry": retry], timeout: 140) { [weak self] value, error in
            guard let self = self, let current = self.preparationIndex(key, token: token, scope: scope) else { return }
            self.preparationRequests.removeValue(forKey: key)
            if let error = error { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription, error: error); return }
            guard let value = value else { self.preparationFailed(key, token: token, scope: scope, note: "Сервер вернул пустой ответ."); return }
            if value["pending"] as? Bool == true {
                self.rows[current]["phase"] = string(value["phase"])
                self.rows[current]["note"] = string(value["note"])
                self.rows[current]["preparation_percent"] = value["preparation_percent"]
                self.save()
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in self?.resolve(key, token: token, scope: scope, until: until) }; return
            }
            do {
                guard let movie = Movie(self.rows[current]["movie"] as? JSON ?? [:]) else { throw failure("Карточка недоступна.") }
                try self.enqueue(movie, links: value, context: string(self.rows[current]["context"]))
                self.preparations.removeValue(forKey: key)
            } catch { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription) }
        }
    }
    private func enqueue(_ movie: Movie, links: JSON, context: String) throws {
        guard !owner.isEmpty, let url = Config.mediaURL(string(links["download_url"])) else { throw failure("Адрес загрузки недоступен.") }
        guard VideoQuality.hintAllowed(links) else { throw failure("Для этого iPad выберите раздачу до 720p (1280×720).") }
        let bytes = Int64(number(links["file_size"]))
        guard bytes > 0, bytes <= Config.maxFileBytes else { throw failure("Сервер не сообщил допустимый размер файла.") }
        let free = ((try? manager.attributesOfFileSystem(forPath: root.path)[.systemFreeSize]) as? NSNumber)?.int64Value ?? 0
        guard free > bytes + Config.reserveBytes + DownloadQueue.reservedBytes(rows, excluding: DownloadDisplay.key(movie, context: context) ?? "") else {
            throw failure("Недостаточно места с учётом других скачиваний. Приостановите их или удалите готовые файлы.")
        }
        guard let identity = DownloadDisplay.key(movie, context: context) else { throw failure("Не удалось определить серию.") }
        let i: Int
        if let old = rows.firstIndex(where: { string($0["key"]) == identity }) {
            guard string(rows[old]["state"]) != "ready" else { throw failure("Этот файл уже доступен офлайн.") }; i = old
        } else { rows.append(["key": identity, "movie": movie.display, "context": context]); i = rows.count - 1 }
        rows[i]["state"] = "downloading"; rows[i]["bytes"] = bytes; rows[i]["received"] = 0
        rows[i]["staging_receipt"] = DownloadReceipt.from(links)
        rows[i].removeValue(forKey: "ack_retry_at"); rows[i].removeValue(forKey: "ack_attempts")
        rows[i].removeValue(forKey: "speed_bps"); rows[i].removeValue(forKey: "speed_at")
        transferSamples.removeValue(forKey: identity)
        rows[i]["note"] = "Загрузка по Wi-Fi"
        let resumeURL = directory.appendingPathComponent(identity + ".resume")
        let task: URLSessionDownloadTask
        if let resume = try? Data(contentsOf: resumeURL) {
            // Signed server URLs can expire. A failed resume is retryable via a newly resolved URL.
            task = session.downloadTask(withResumeData: resume); try? manager.removeItem(at: resumeURL)
        } else {
            var request = URLRequest(url: url)
            Config.requestHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
            request.setValue("video/mp4", forHTTPHeaderField: "Accept")
            task = session.downloadTask(with: request)
        }
        task.taskDescription = owner + "|" + identity
        rows[i]["task_id"] = task.taskIdentifier; save(); task.resume()
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let i = index(downloadTask) else { return }
        let key = string(rows[i]["key"]), now = Date()
        if let previous = transferSamples[key], now.timeIntervalSince(previous.0) >= 1 {
            let speed = max(0, Double(totalBytesWritten - previous.1) / now.timeIntervalSince(previous.0))
            rows[i]["speed_bps"] = speed; rows[i]["speed_at"] = now.timeIntervalSince1970
            transferSamples[key] = (now, totalBytesWritten)
        } else if transferSamples[key] == nil { transferSamples[key] = (now, totalBytesWritten) }
        rows[i]["received"] = totalBytesWritten
        if Date().timeIntervalSince(lastSave) > 2 { lastSave = Date(); save() }
    }
    private func index(_ task: URLSessionTask) -> Int? {
        guard let description = task.taskDescription, description.hasPrefix(owner + "|") else { return nil }
        let key = String(description.dropFirst(owner.count + 1))
        return rows.firstIndex { string($0["key"]) == key && string($0["state"]) == "downloading" &&
            ($0["task_id"] == nil || Int(number($0["task_id"])) == task.taskIdentifier) }
    }
    func poster(_ row: JSON) -> UIImage? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        return UIImage(contentsOfFile: directory.appendingPathComponent(key + ".jpg").path)
    }
    private func savePoster(_ movie: Movie, key: String) {
        let scope = owner; let destination = directory.appendingPathComponent(key + ".jpg")
        // A local title card is always present, even if the remote poster is unavailable.
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 300, height: 450), true, 1)
        Theme.panel.setFill(); UIRectFill(CGRect(x: 0, y: 0, width: 300, height: 450))
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 25), .foregroundColor: UIColor.white]
        (movie.title as NSString).draw(in: CGRect(x: 22, y: 160, width: 256, height: 220), withAttributes: attributes)
        let placeholder = UIGraphicsGetImageFromCurrentImageContext(); UIGraphicsEndImageContext()
        if !manager.fileExists(atPath: destination.path), let data = placeholder?.jpegData(compressionQuality: 0.8) {
            try? manager.createDirectory(at: directory, withIntermediateDirectories: true)
            try? data.write(to: destination, options: .atomic)
        }
        guard !movie.poster.isEmpty, !posterRequests.contains(scope + "|" + key),
            (posterRetryAt[scope + "|" + key] ?? .distantPast) < Date() else { return }
        let requestKey = scope + "|" + key; posterRequests.insert(requestKey)
        Posters.shared.fetch(movie.poster) { image in
                self.posterRequests.remove(requestKey)
                self.posterRetryAt[requestKey] = Date().addingTimeInterval(60)
                guard self.owner == scope, self.rows.contains(where: { string($0["key"]) == key }),
                    let data = image?.jpegData(compressionQuality: 0.85) else { return }
                do { try data.write(to: destination, options: .atomic) } catch { return }
                if let i = self.rows.firstIndex(where: { string($0["key"]) == key }) {
                    self.rows[i]["poster_saved"] = true; self.save()
                }
                NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
        }
    }
    func repairPosters() {
        guard AppDelegate.current.authenticated, AppDelegate.current.serverReachable else { return }
        for row in rows where row["poster_saved"] as? Bool != true || poster(row) == nil {
            if let movie = Movie(row["movie"] as? JSON ?? [:]) { savePoster(movie, key: string(row["key"])) }
        }
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let i = index(downloadTask) else { return }
        let key = string(rows[i]["key"]); let scope = owner
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, [200, 206].contains(response.statusCode),
                response.url.map({ Config.trusted($0) }) == true else { throw failure("Сервер отклонил загрузку. Повторите подготовку файла.") }
            let size = ((try manager.attributesOfItem(atPath: location.path))[.size] as? NSNumber)?.int64Value ?? 0
            guard size == Int64(number(rows[i]["bytes"])) else { throw failure("Файл получен не полностью.") }
            let destination = directory.appendingPathComponent(key + ".mp4")
            try? manager.removeItem(at: destination); try manager.moveItem(at: location, to: destination)
            try manager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
            rows[i]["state"] = "verifying"; rows[i]["note"] = "Проверяем видео"; save()
            let asset = AVURLAsset(url: destination)
            asset.loadValuesAsynchronously(forKeys: ["playable", "tracks", "duration"]) { DispatchQueue.main.async {
                guard self.owner == scope, let current = self.rows.firstIndex(where: { string($0["key"]) == key &&
                    string($0["state"]) == "verifying" && Int(number($0["task_id"])) == downloadTask.taskIdentifier }) else { return }
                var error: NSError?
                let loaded = ["playable", "tracks", "duration"].allSatisfy { asset.statusOfValue(forKey: $0, error: &error) == .loaded }
                let video = asset.tracks(withMediaType: .video).first
                let descriptions = video?.formatDescriptions as? [CMFormatDescription] ?? []
                let h264 = descriptions.contains { CMFormatDescriptionGetMediaSubType($0) == kCMVideoCodecType_H264 }
                let aac = asset.tracks(withMediaType: .audio).allSatisfy { track in
                    let formats = track.formatDescriptions as? [CMFormatDescription] ?? []
                    return !formats.isEmpty && formats.allSatisfy { format in
                        guard let audio = CMAudioFormatDescriptionGetStreamBasicDescription(format)?.pointee else { return false }
                        return audio.mFormatID == kAudioFormatMPEG4AAC && audio.mChannelsPerFrame <= 2 && audio.mSampleRate <= 48000
                    }
                }
                let dimensions = video.map { $0.naturalSize.applying($0.preferredTransform) } ?? .zero
                let allowed = VideoQuality.dimensionsAllowed(width: Double(abs(dimensions.width)), height: Double(abs(dimensions.height)))
                guard loaded, asset.isPlayable, h264, aac, allowed, (video?.nominalFrameRate ?? 0) <= 60, CMTimeGetSeconds(asset.duration).isFinite,
                    CMTimeGetSeconds(asset.duration) > 0 else {
                    try? self.manager.removeItem(at: destination)
                    self.rows[current]["state"] = "error"; self.rows[current]["note"] = "Файл не подходит этому iPad. Выберите другую раздачу H.264 до 720p."
                    self.save(); return
                }
                let receipt = self.rows[current]["staging_receipt"] as? JSON
                self.rows[current]["note"] = "Проверяем целостность скачанного файла…"; self.save()
                DispatchQueue.global(qos: .utility).async {
                    let expected = string(receipt?["digest"])
                    let actual = expected.isEmpty ? "" : FileDigest.sha256(destination)
                    DispatchQueue.main.async {
                        guard self.owner == scope, let index = self.rows.firstIndex(where: { string($0["key"]) == key &&
                            string($0["state"]) == "verifying" && Int(number($0["task_id"])) == downloadTask.taskIdentifier }) else { return }
                        guard expected.isEmpty || actual == expected else {
                            self.rows[index]["state"] = "error"; self.rows[index]["note"] = "Контрольная сумма не совпала. Серверную копию сохранили; повторите скачивание."
                            try? self.manager.removeItem(at: destination); self.save(); return
                        }
                        self.rows[index]["state"] = "ready"; self.rows[index]["note"] = "Доступно без интернета"
                        self.rows[index]["received"] = size; self.rows[index]["duration"] = CMTimeGetSeconds(asset.duration)
                        self.transferSamples.removeValue(forKey: key); self.save(); self.acknowledgeReadyFiles()
                    }
                }
            }}
        } catch { rows[i]["state"] = "error"; rows[i]["note"] = error.localizedDescription; save() }
    }
    private func acknowledgeReadyFiles() {
        guard !owner.isEmpty, AppDelegate.current.authenticated, UIApplication.shared.applicationState == .active else { return }
        let scope = owner
        // Do not release the server copy until the ready entry has been durably written.
        guard let data = try? Data(contentsOf: directory.appendingPathComponent("index.json")),
            let persisted = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
            string(persisted["owner"]) == scope, let saved = persisted["items"] as? [JSON] else { return }
        for row in rows where string(row["state"]) == "ready" {
            let key = string(row["key"])
            guard acknowledgements[key] == nil, file(row) != nil,
                number(row["ack_retry_at"]) <= Date().timeIntervalSince1970,
                let receipt = row["staging_receipt"] as? JSON, let payload = DownloadReceipt.payload(receipt) else { continue }
            guard saved.contains(where: { string($0["key"]) == key && string($0["state"]) == "ready" &&
                string(($0["staging_receipt"] as? JSON)?["digest"]) == string(payload["digest"]) &&
                number($0["bytes"]) == number(payload["size"]) }) else { continue }
            let token = UUID(); acknowledgements[key] = token
            acknowledgementRequests[key] = API.shared.call("api/device-queue", method: "POST", body: payload) { [weak self] value, error in
                guard let self = self, self.owner == scope, self.acknowledgements[key] == token else { return }
                self.acknowledgements.removeValue(forKey: key); self.acknowledgementRequests.removeValue(forKey: key)
                guard let i = self.rows.firstIndex(where: { string($0["key"]) == key && string($0["state"]) == "ready" }),
                    let pending = self.rows[i]["staging_receipt"] as? JSON,
                    string(pending["id"]) == string(payload["id"]), string(pending["digest"]) == string(payload["digest"]) else { return }
                if DownloadReceipt.completed(value, error: error) {
                    self.rows[i].removeValue(forKey: "staging_receipt")
                    self.rows[i].removeValue(forKey: "ack_retry_at"); self.rows[i].removeValue(forKey: "ack_attempts")
                } else {
                    let attempts = min(8, Int(number(self.rows[i]["ack_attempts"])) + 1)
                    self.rows[i]["ack_attempts"] = attempts
                    self.rows[i]["ack_retry_at"] = Date().timeIntervalSince1970 + min(300, pow(2, Double(attempts)) * 5)
                }
                self.save(); self.scheduleAcknowledgementRetry()
            }
        }
        scheduleAcknowledgementRetry()
    }
    private func scheduleAcknowledgementRetry() {
        guard !acknowledgementRetryScheduled, rows.contains(where: { string($0["state"]) == "ready" && $0["staging_receipt"] != nil }) else { return }
        acknowledgementRetryScheduled = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 15) { [weak self] in
            guard let self = self else { return }; self.acknowledgementRetryScheduled = false
            self.acknowledgeReadyFiles()
        }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error as NSError?, let i = index(task) else { return }
        if let data = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            try? data.write(to: directory.appendingPathComponent(string(rows[i]["key"]) + ".resume"), options: .atomic)
        }
        if DownloadQueue.connectionFailure(error), !string(rows[i]["ref"]).isEmpty {
            connectionBlocked = true; rows[i]["state"] = "queued"; rows[i]["note"] = "Ожидаем подключения к Медиатеке."
        } else { rows[i]["state"] = "paused"; rows[i]["note"] = "Загрузка прервана. Можно продолжить." }
        save()
    }
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async { let done = self.backgroundCompletion; self.backgroundCompletion = nil; done?() }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map { Config.trusted($0) } == true ? request : nil)
    }
}
