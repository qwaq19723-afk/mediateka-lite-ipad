import UIKit
import ImageIO

enum Theme {
    static let background = UIColor(red: 0.035, green: 0.067, blue: 0.106, alpha: 1)
    static let panel = UIColor(red: 0.078, green: 0.133, blue: 0.188, alpha: 1)
    static let accent = UIColor(red: 0.57, green: 0.86, blue: 0.76, alpha: 1)
    static let muted = UIColor(red: 0.65, green: 0.72, blue: 0.78, alpha: 1)
    static func homeIcon() -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 30, height: 30), false, 0)
        defer { UIGraphicsEndImageContext() }
        UIColor.white.setStroke()
        let path = UIBezierPath(); path.lineWidth = 2.2; path.lineJoinStyle = .round; path.lineCapStyle = .round
        path.move(to: CGPoint(x: 3, y: 14)); path.addLine(to: CGPoint(x: 15, y: 4)); path.addLine(to: CGPoint(x: 27, y: 14))
        path.move(to: CGPoint(x: 6, y: 12)); path.addLine(to: CGPoint(x: 6, y: 26)); path.addLine(to: CGPoint(x: 12, y: 26))
        path.addLine(to: CGPoint(x: 12, y: 18)); path.addLine(to: CGPoint(x: 18, y: 18)); path.addLine(to: CGPoint(x: 18, y: 26))
        path.addLine(to: CGPoint(x: 24, y: 26)); path.addLine(to: CGPoint(x: 24, y: 12)); path.stroke()
        return UIGraphicsGetImageFromCurrentImageContext()?.withRenderingMode(.alwaysTemplate)
    }
    static func label(_ size: CGFloat, bold: Bool = false) -> UILabel {
        let label = UILabel(); label.textColor = .white
        label.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size)
        label.numberOfLines = 0; return label
    }
    static func button(_ title: String, target: Any, action: Selector) -> UIButton {
        let button = UIButton(type: .system); button.setTitle(title, for: .normal)
        button.setTitleColor(.white, for: .normal); button.titleLabel?.font = .systemFont(ofSize: 18, weight: .medium)
        button.backgroundColor = panel; button.layer.cornerRadius = 12
        button.layer.borderWidth = 1; button.layer.borderColor = accent.withAlphaComponent(0.5).cgColor
        button.contentEdgeInsets = UIEdgeInsets(top: 14, left: 20, bottom: 14, right: 20)
        button.addTarget(target, action: action, for: .touchUpInside); return button
    }
    static func setup() {
        UINavigationBar.appearance().barStyle = .black
        UINavigationBar.appearance().barTintColor = background
        UINavigationBar.appearance().tintColor = accent
        UINavigationBar.appearance().isTranslucent = false
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        UITabBar.appearance().barStyle = .black; UITabBar.appearance().barTintColor = background
        UITabBar.appearance().tintColor = accent; UITabBar.appearance().isTranslucent = false
    }
}

extension UIViewController {
    func message(_ text: String) {
        let alert = UIAlertController(title: "Медиатека", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Понятно", style: .default)); present(alert, animated: true)
    }
}

// Network concurrency is bounded independently of thumbnail decoding.
final class Posters {
    static let shared = Posters()
    private let cache = NSCache<NSString, UIImage>()
    private let queue = OperationQueue()
    private let session: URLSession
    private var pending: [String] = []
    private var listeners: [String: [(UIImage?) -> Void]] = [:]
    private var active: Set<String> = []
    private var tasks: [String: URLSessionDataTask] = [:]
    private var generation = 0
    init() {
        cache.countLimit = 48; cache.totalCostLimit = 16 * 1024 * 1024
        queue.maxConcurrentOperationCount = 2
        let config = URLSessionConfiguration.default
        config.httpMaximumConnectionsPerHost = 3
        config.httpCookieStorage = HTTPCookieStorage.shared
        config.urlCache = URLCache.shared
        session = URLSession(configuration: config)
    }
    func load(_ value: String, into view: UIImageView) {
        view.image = nil; view.accessibilityIdentifier = value
        fetch(value) { [weak view] image in
            if view?.accessibilityIdentifier == value { view?.image = image }
        }
    }
    // All state and callbacks are confined to the main queue.
    func fetch(_ value: String, done: @escaping (UIImage?) -> Void) {
        guard !value.isEmpty, Config.mediaURL(value) != nil else { done(nil); return }
        if let image = cache.object(forKey: value as NSString) { done(image); return }
        if listeners[value] != nil { listeners[value]?.append(done); return }
        listeners[value] = [done]; pending.append(value); pump()
    }
    private func pump() {
        while active.count < 3 && !pending.isEmpty {
            let value = pending.removeFirst()
            active.insert(value); request(value, attempt: 0, token: generation)
        }
    }
    private func request(_ value: String, attempt: Int, token: Int) {
        guard generation == token, let url = Config.mediaURL(value) else { return }
        var request = URLRequest(url: url, cachePolicy: attempt == 0 ? .returnCacheDataElseLoad : .reloadIgnoringLocalCacheData,
                                 timeoutInterval: 30)
        Config.requestHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
        request.setValue("image/*", forHTTPHeaderField: "Accept")
        let task = session.dataTask(with: request) { data, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let retryable = error != nil || status == 408 || status == 429 || status >= 500
            guard status == 200, let data = data, !data.isEmpty, data.count <= 8 * 1024 * 1024 else {
                DispatchQueue.main.async { self.finish(value, image: nil, retry: retryable, attempt: attempt, token: token) }
                return
            }
            self.queue.addOperation {
                let image: UIImage? = autoreleasepool {
                    guard let source = CGImageSourceCreateWithData(data as CFData, nil),
                        let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0,
                            [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 600,
                             kCGImageSourceCreateThumbnailWithTransform: true] as CFDictionary) else { return nil }
                    return UIImage(cgImage: bitmap)
                }
                DispatchQueue.main.async { self.finish(value, image: image, retry: image == nil, attempt: attempt, token: token) }
            }
        }
        tasks[value] = task; task.resume()
    }
    private func finish(_ value: String, image: UIImage?, retry: Bool, attempt: Int, token: Int) {
        guard token == generation else { return }
        tasks.removeValue(forKey: value)
        if image == nil && retry && attempt < 2 {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(attempt + 1) * 2) {
                self.request(value, attempt: attempt + 1, token: token)
            }
            return
        }
        if let image = image { cache.setObject(image, forKey: value as NSString, cost: Int(image.size.width * image.size.height * 4)) }
        let callbacks = listeners.removeValue(forKey: value) ?? []
        active.remove(value); callbacks.forEach { $0(image) }; pump()
    }
    func trimMemory() { cache.removeAllObjects() }
    func clear() {
        generation += 1; tasks.values.forEach { $0.cancel() }
        let callbacks = listeners.values.flatMap { $0 }
        tasks.removeAll(); pending.removeAll(); listeners.removeAll(); active.removeAll()
        cache.removeAllObjects(); URLCache.shared.removeAllCachedResponses()
        callbacks.forEach { $0(nil) }
    }
}
