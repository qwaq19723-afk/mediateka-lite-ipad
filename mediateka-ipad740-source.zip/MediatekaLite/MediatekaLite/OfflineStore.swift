import Foundation
import AVFoundation
import CoreMedia
import UIKit
import ImageIO
import AudioToolbox

final class OfflineStore: NSObject, URLSessionDownloadDelegate {
    static let shared = OfflineStore()
    static let changed = Notification.Name("OfflineChanged740")
    private(set) var owner = UserDefaults.standard.string(forKey: "lastOwner740") ?? ""
    private(set) var rows: [JSON] = []
    var backgroundCompletion: (() -> Void)?
    private var lastSave = Date.distantPast
    private let manager = FileManager.default
    private lazy var root: URL = {
        let base = manager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Offline740", isDirectory: true)
        try? manager.createDirectory(at: base, withIntermediateDirectories: true)
        var folder = base; var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? folder.setResourceValues(values)
        return folder
    }()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Config.bundle + ".downloads")
        config.httpCookieStorage = HTTPCookieStorage.shared; config.httpShouldSetCookies = true
        config.httpMaximumConnectionsPerHost = 1; config.allowsCellularAccess = false
        config.isDiscretionary = false; config.sessionSendsLaunchEvents = true
        return URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue.main)
    }()
    private var directory: URL { return root.appendingPathComponent(owner.isEmpty ? "none" : owner, isDirectory: true) }
    override init() { super.init(); read() }
    func activate() {
        session.getAllTasks { tasks in DispatchQueue.main.async {
            let active = Set(tasks.compactMap { $0.taskDescription })
            for index in self.rows.indices where ["downloading", "verifying"].contains(string(self.rows[index]["state"])) {
                if !active.contains(self.owner + "|" + string(self.rows[index]["key"])) {
                    self.rows[index]["state"] = "paused"; self.rows[index]["note"] = "Продолжите загрузку."
                }
            }
            self.save()
        }}
    }
    func switchOwner(_ value: String) {
        guard value.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return }
        if owner != value {
            let previous = owner + "|"
            session.getAllTasks { tasks in tasks.filter { $0.taskDescription?.hasPrefix(previous) == true }.forEach { $0.cancel() } }
            owner = value; UserDefaults.standard.set(value, forKey: "lastOwner740"); read(); save()
        }
        activate()
    }
    private func read() {
        guard owner.isEmpty || owner.range(of: "^[0-9]+$", options: .regularExpression) != nil else { owner = ""; rows = []; return }
        guard let data = try? Data(contentsOf: directory.appendingPathComponent("index.json")),
            let value = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
            string(value["owner"]) == owner, number(value["schema"]) == 1,
            let list = value["items"] as? [JSON] else { rows = []; return }
        rows = list.filter { row in
            let key = string(row["key"])
            return key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil
        }
        for i in rows.indices where string(rows[i]["state"]) == "ready" {
            if file(rows[i]) == nil { rows[i]["state"] = "error"; rows[i]["note"] = "Файл отсутствует или повреждён." }
        }
    }
    private func save() {
        guard !owner.isEmpty else { return }
        try? manager.createDirectory(at: directory, withIntermediateDirectories: true)
        if let data = try? JSONSerialization.data(withJSONObject: ["schema": 1, "owner": owner, "items": rows]) {
            try? data.write(to: directory.appendingPathComponent("index.json"), options: .atomic)
        }
        NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
    }
    func file(_ row: JSON) -> URL? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        let url = directory.appendingPathComponent(key + ".mp4")
        guard let attrs = try? manager.attributesOfItem(atPath: url.path),
            let size = attrs[.size] as? NSNumber, size.int64Value > 0,
            size.int64Value == (row["bytes"] as? NSNumber)?.int64Value else { return nil }
        return url
    }
    func remove(_ key: String) {
        guard let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        let scope = owner
        session.getAllTasks { tasks in tasks.filter { $0.taskDescription == scope + "|" + key }.forEach { $0.cancel() } }
        let url = directory.appendingPathComponent(key + ".mp4")
        try? manager.removeItem(at: url); try? manager.removeItem(at: directory.appendingPathComponent(key + ".resume"))
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".jpg"))
        if owner == scope { rows.remove(at: i); save() }
    }
    func position(_ key: String, seconds: Double) {
        guard seconds.isFinite, let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        rows[i]["position"] = max(0, seconds); save()
    }
    func pause(_ key: String) {
        let scope = owner; let folder = directory
        session.getAllTasks { tasks in
            for task in tasks where task.taskDescription == scope + "|" + key {
                (task as? URLSessionDownloadTask)?.cancel(byProducingResumeData: { data in DispatchQueue.main.async {
                    guard self.owner == scope, let i = self.rows.firstIndex(where: { string($0["key"]) == key }) else { return }
                    if let data = data { try? data.write(to: folder.appendingPathComponent(key + ".resume"), options: .atomic) }
                    self.rows[i]["state"] = "paused"; self.rows[i]["note"] = "Приостановлено"; self.save()
                }})
            }
        }
    }
    func enqueue(_ movie: Movie, links: JSON, context: String) throws {
        guard !owner.isEmpty, let url = Config.mediaURL(string(links["download_url"])) else { throw failure("Адрес загрузки недоступен.") }
        let bytes = Int64(number(links["file_size"]))
        guard bytes > 0, bytes <= Config.maxFileBytes else { throw failure("Сервер не сообщил допустимый размер файла.") }
        let free = ((try? manager.attributesOfFileSystem(forPath: root.path)[.systemFreeSize]) as? NSNumber)?.int64Value ?? 0
        guard free > bytes + Config.reserveBytes else { throw failure("Недостаточно свободного места. Удалите другие загрузки.") }
        guard !rows.contains(where: { ["downloading", "verifying"].contains(string($0["state"])) }) else {
            throw failure("На этом iPad загружаем по одному файлу. Дождитесь окончания или приостановите загрузку.")
        }
        let identity = movie.key + (context.isEmpty ? "" : "-" + context)
        guard identity.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { throw failure("Не удалось определить серию.") }
        let i: Int
        if let old = rows.firstIndex(where: { string($0["key"]) == identity }) {
            guard string(rows[old]["state"]) != "ready" else { throw failure("Этот файл уже доступен офлайн.") }; i = old
        } else { rows.append(["key": identity, "movie": movie.display, "context": context]); i = rows.count - 1 }
        rows[i]["state"] = "downloading"; rows[i]["bytes"] = bytes; rows[i]["received"] = 0
        rows[i]["note"] = "Загрузка по Wi-Fi"; save()
        savePoster(movie, key: identity)
        let resumeURL = directory.appendingPathComponent(identity + ".resume")
        let task: URLSessionDownloadTask
        if let resume = try? Data(contentsOf: resumeURL) {
            // Signed server URLs can expire. A failed resume is retryable via a newly resolved URL.
            task = session.downloadTask(withResumeData: resume); try? manager.removeItem(at: resumeURL)
        } else {
            var request = URLRequest(url: url); request.setValue("mobile", forHTTPHeaderField: "X-Mediateka-Device718")
            task = session.downloadTask(with: request)
        }
        task.taskDescription = owner + "|" + identity; task.resume()
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let i = index(downloadTask) else { return }
        rows[i]["received"] = totalBytesWritten
        if Date().timeIntervalSince(lastSave) > 2 { lastSave = Date(); save() }
    }
    private func index(_ task: URLSessionTask) -> Int? {
        guard let description = task.taskDescription, description.hasPrefix(owner + "|") else { return nil }
        let key = String(description.dropFirst(owner.count + 1))
        return rows.firstIndex { string($0["key"]) == key && string($0["state"]) == "downloading" }
    }
    func poster(_ row: JSON) -> UIImage? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        return UIImage(contentsOfFile: directory.appendingPathComponent(key + ".jpg").path)
    }
    private func savePoster(_ movie: Movie, key: String) {
        let scope = owner; let destination = directory.appendingPathComponent(key + ".jpg")
        // A local title card is always present, even if the remote poster is unavailable.
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 300, height: 450), true, 1)
        Theme.panel.setFill(); UIRectFill(CGRect(x: 0, y: 0, width: 300, height: 450))
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 25), .foregroundColor: UIColor.white]
        (movie.title as NSString).draw(in: CGRect(x: 22, y: 160, width: 256, height: 220), withAttributes: attributes)
        let placeholder = UIGraphicsGetImageFromCurrentImageContext(); UIGraphicsEndImageContext()
        if let data = placeholder?.jpegData(compressionQuality: 0.8) { try? data.write(to: destination, options: .atomic) }
        guard let url = Config.mediaURL(movie.poster), !movie.poster.isEmpty else { return }
        URLSession.shared.dataTask(with: url) { data, response, _ in
            guard (response as? HTTPURLResponse)?.statusCode == 200, let data = data, data.count <= 2 * 1024 * 1024,
                let source = CGImageSourceCreateWithData(data as CFData, nil),
                let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0,
                    [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 600,
                     kCGImageSourceCreateThumbnailWithTransform: true] as CFDictionary) else { return }
            let image = UIImage(cgImage: bitmap)
            DispatchQueue.main.async {
                guard self.owner == scope, self.rows.contains(where: { string($0["key"]) == key }),
                    let data = image.jpegData(compressionQuality: 0.85) else { return }
                try? data.write(to: destination, options: .atomic)
                NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
            }
        }.resume()
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let i = index(downloadTask) else { return }
        let key = string(rows[i]["key"]); let scope = owner
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, response.statusCode == 200,
                response.url.map({ Config.trusted($0) }) == true else { throw failure("Сервер отклонил загрузку. Повторите подготовку файла.") }
            let size = ((try manager.attributesOfItem(atPath: location.path))[.size] as? NSNumber)?.int64Value ?? 0
            guard size == Int64(number(rows[i]["bytes"])) else { throw failure("Файл получен не полностью.") }
            let destination = directory.appendingPathComponent(key + ".mp4")
            try? manager.removeItem(at: destination); try manager.moveItem(at: location, to: destination)
            try manager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
            rows[i]["state"] = "verifying"; rows[i]["note"] = "Проверяем видео"; save()
            let asset = AVURLAsset(url: destination)
            asset.loadValuesAsynchronously(forKeys: ["playable", "tracks", "duration"]) { DispatchQueue.main.async {
                guard self.owner == scope, let current = self.rows.firstIndex(where: { string($0["key"]) == key }) else { return }
                var error: NSError?
                let loaded = ["playable", "tracks", "duration"].allSatisfy { asset.statusOfValue(forKey: $0, error: &error) == .loaded }
                let video = asset.tracks(withMediaType: .video).first
                let descriptions = video?.formatDescriptions as? [CMFormatDescription] ?? []
                let h264 = descriptions.contains { CMFormatDescriptionGetMediaSubType($0) == kCMVideoCodecType_H264 }
                let aac = asset.tracks(withMediaType: .audio).allSatisfy { track in
                    let formats = track.formatDescriptions as? [CMFormatDescription] ?? []
                    return !formats.isEmpty && formats.allSatisfy { format in
                        guard let audio = CMAudioFormatDescriptionGetStreamBasicDescription(format)?.pointee else { return false }
                        return audio.mFormatID == kAudioFormatMPEG4AAC && audio.mChannelsPerFrame <= 2 && audio.mSampleRate <= 48000
                    }
                }
                let dimensions = video.map { $0.naturalSize.applying($0.preferredTransform) } ?? .zero
                let allowed = max(abs(dimensions.width), abs(dimensions.height)) <= 1920 && min(abs(dimensions.width), abs(dimensions.height)) <= 1080
                guard loaded, asset.isPlayable, h264, aac, allowed, (video?.nominalFrameRate ?? 0) <= 60, CMTimeGetSeconds(asset.duration).isFinite,
                    CMTimeGetSeconds(asset.duration) > 0 else {
                    try? self.manager.removeItem(at: destination)
                    self.rows[current]["state"] = "error"; self.rows[current]["note"] = "Файл не подходит этому iPad. Выберите другую раздачу H.264 до Full HD."
                    self.save(); return
                }
                self.rows[current]["state"] = "ready"; self.rows[current]["note"] = "Доступно без интернета"
                self.rows[current]["received"] = size; self.rows[current]["duration"] = CMTimeGetSeconds(asset.duration); self.save()
            }}
        } catch { rows[i]["state"] = "error"; rows[i]["note"] = error.localizedDescription; save() }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error as NSError?, let i = index(task) else { return }
        if let data = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            try? data.write(to: directory.appendingPathComponent(string(rows[i]["key"]) + ".resume"), options: .atomic)
        }
        rows[i]["state"] = "paused"; rows[i]["note"] = "Загрузка прервана. Можно продолжить."; save()
    }
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async { let done = self.backgroundCompletion; self.backgroundCompletion = nil; done?() }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map { Config.trusted($0) } == true ? request : nil)
    }
}
