import UIKit
import ImageIO

enum Theme {
    static let background = UIColor(red: 0.035, green: 0.067, blue: 0.106, alpha: 1)
    static let panel = UIColor(red: 0.078, green: 0.133, blue: 0.188, alpha: 1)
    static let accent = UIColor(red: 0.57, green: 0.86, blue: 0.76, alpha: 1)
    static let muted = UIColor(red: 0.65, green: 0.72, blue: 0.78, alpha: 1)
    static func label(_ size: CGFloat, bold: Bool = false) -> UILabel {
        let label = UILabel(); label.textColor = .white
        label.font = bold ? .boldSystemFont(ofSize: size) : .systemFont(ofSize: size)
        label.numberOfLines = 0; return label
    }
    static func button(_ title: String, target: Any, action: Selector) -> UIButton {
        let button = UIButton(type: .system); button.setTitle(title, for: .normal)
        button.setTitleColor(.white, for: .normal); button.titleLabel?.font = .systemFont(ofSize: 18, weight: .medium)
        button.backgroundColor = panel; button.layer.cornerRadius = 12
        button.layer.borderWidth = 1; button.layer.borderColor = accent.withAlphaComponent(0.5).cgColor
        button.contentEdgeInsets = UIEdgeInsets(top: 14, left: 20, bottom: 14, right: 20)
        button.addTarget(target, action: action, for: .touchUpInside); return button
    }
    static func setup() {
        UINavigationBar.appearance().barStyle = .black
        UINavigationBar.appearance().barTintColor = background
        UINavigationBar.appearance().tintColor = accent
        UINavigationBar.appearance().isTranslucent = false
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        UITabBar.appearance().barStyle = .black; UITabBar.appearance().barTintColor = background
        UITabBar.appearance().tintColor = accent; UITabBar.appearance().isTranslucent = false
    }
}

extension UIViewController {
    func message(_ text: String) {
        let alert = UIAlertController(title: "Медиатека", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Понятно", style: .default)); present(alert, animated: true)
    }
}

// At most 24 downsampled posters in memory. Reuse never replaces the wrong cell.
final class Posters {
    static let shared = Posters()
    private let cache = NSCache<NSString, UIImage>()
    private let queue = OperationQueue()
    init() { cache.countLimit = 24; cache.totalCostLimit = 12 * 1024 * 1024; queue.maxConcurrentOperationCount = 2 }
    func load(_ value: String, into view: UIImageView) {
        view.image = nil; view.accessibilityIdentifier = value
        guard let url = Config.mediaURL(value), !value.isEmpty else { return }
        if let image = cache.object(forKey: value as NSString) { view.image = image; return }
        let request = URLRequest(url: url, cachePolicy: .returnCacheDataElseLoad, timeoutInterval: 15)
        URLSession.shared.dataTask(with: request) { [weak view] data, response, _ in
            guard (response as? HTTPURLResponse)?.statusCode == 200, let data = data, data.count <= 2 * 1024 * 1024 else { return }
            self.queue.addOperation {
                guard let source = CGImageSourceCreateWithData(data as CFData, nil),
                    let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0,
                        [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 600,
                         kCGImageSourceCreateThumbnailWithTransform: true] as CFDictionary) else { return }
                let image = UIImage(cgImage: bitmap); self.cache.setObject(image, forKey: value as NSString, cost: bitmap.bytesPerRow * bitmap.height)
                DispatchQueue.main.async { if view?.accessibilityIdentifier == value { view?.image = image } }
            }
        }.resume()
    }
    func clear() { cache.removeAllObjects(); URLCache.shared.removeAllCachedResponses() }
}
