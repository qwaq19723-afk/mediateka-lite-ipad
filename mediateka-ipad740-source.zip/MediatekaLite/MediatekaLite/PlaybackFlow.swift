import UIKit
import AVKit

final class PlaybackFlow: UITableViewController {
    private let movie: Movie
    private let download: Bool
    private var task: URLSessionDataTask?
    private var revision = 0
    private var expires = Date()
    private var options: [JSON] = []
    private var alternatives: [JSON] = []
    private var season = 0
    private var episode = 0
    private var progress = "Ищем доступный источник…"
    private var route = ""
    private var sessionID = ""
    private var player: LitePlayer?
    private var heartbeat: Timer?
    private var stopped = false
    init(movie: Movie, download: Bool) { self.movie = movie; self.download = download; super.init(style: .plain) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func viewDidLoad() {
        super.viewDidLoad(); title = movie.title
        tableView.backgroundColor = Theme.background; tableView.separatorColor = Theme.panel; tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 70
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Отмена", style: .plain, target: self, action: #selector(cancel))
        expires = Date().addingTimeInterval(180); open()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isMovingFromParent || navigationController?.isBeingDismissed == true { stop() }
    }
    @objc private func cancel() { stop(); navigationController?.popViewController(animated: true) }
    private func stop() {
        guard !stopped else { return }; stopped = true; revision += 1; task?.cancel(); heartbeat?.invalidate(); player?.player?.pause()
        if !sessionID.isEmpty { API.shared.call(route + "/" + sessionID, method: "DELETE") { _, _ in } }
    }
    private func request(_ path: String, method: String = "GET", body: JSON? = nil, timeout: TimeInterval = 25,
                         then: @escaping (JSON) -> Void) {
        let token = revision
        task = API.shared.call(path, method: method, body: body, timeout: timeout) { [weak self] json, error in
            guard let self = self, !self.stopped, self.revision == token else { return }
            if let error = error { self.showError(error.localizedDescription); return }
            guard let json = json else { self.showError("Сервер вернул пустой ответ."); return }; then(json)
        }
    }
    private func later(_ seconds: Double = 1, action: @escaping () -> Void) {
        let token = revision
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
            guard let self = self, !self.stopped, self.revision == token else { return }
            if Date() > self.expires { self.showError("Подготовка заняла больше времени. Вернитесь к карточке и повторите попытку."); return }
            action()
        }
    }
    private func showError(_ message: String) { progress = message; options = []; tableView.reloadData() }
    private func open() {
        request("api/atv/detail/" + movie.kind + "/" + movie.id) { [weak self] detail in
            guard let self = self else { return }; let choice = string(detail["choice"])
            guard !choice.isEmpty else { self.showError("Карточка недоступна."); return }
            if self.movie.kind == "tv" { self.operation(choice) }
            else { self.availability(choice) }
        }
    }
    private func availability(_ choice: String) {
        request("api/watch-availability?id=" + API.query(choice), timeout: 80) { [weak self] value in
            guard let self = self else { return }
            guard !string(value["id"]).isEmpty else { self.showError(string(value["note"])); return }
            self.operation(string(value["id"]))
        }
    }
    private func operation(_ choice: String) {
        progress = "Проверяем источник…"; options = []; tableView.reloadData(); expires = Date().addingTimeInterval(180)
        request("api/operations", method: "POST", body: ["action": "open", "media": "movies", "id": choice]) { [weak self] value in
            guard let self = self else { return }
            let id = string(value["id"]); guard !id.isEmpty else { self.showError("Не удалось начать поиск."); return }
            self.pollOperation(id)
        }
    }
    private func pollOperation(_ id: String) {
        request("api/operations/" + API.query(id)) { [weak self] value in
            guard let self = self else { return }; let state = string(value["status"] ?? value["state"])
            if ["failed", "cancelled"].contains(state) { self.showError(string(value["error"])); return }
            if let result = value["result"] as? JSON { self.consume(result); return }
            if ["done", "completed"].contains(state) { self.consume(value); return }
            self.progress = string(value["note"]).isEmpty ? "Ищем раздачу…" : string(value["note"]); self.tableView.reloadData()
            self.later { self.pollOperation(id) }
        }
    }
    private func consume(_ result: JSON) {
        if number(result["season"]) > 0 { season = Int(number(result["season"])) }
        if number(result["episode"]) > 0 { episode = Int(number(result["episode"])) }
        let found: [JSON] = ["alternatives", "next_source", "reserve"].compactMap { key in
            let id = string(result[key]); return id.isEmpty ? nil : ["id": id, "title": key == "reserve" ? "Другой сервис" : "Другая раздача"]
        }
        if !found.isEmpty { alternatives = found }
        if let nested = result["player"] as? JSON ?? result["links"] as? JSON { consume(nested); return }
        if result["torrent_ticket"] != nil || result["playback_ticket"] != nil || result["download_url"] != nil {
            if download { prepareDownload(result) } else { startPlayback(result) }; return
        }
        let values = (result["items"] as? [JSON]) ?? (result["episodes"] as? [JSON]) ?? (result["seasons"] as? [JSON]) ?? (result["choices"] as? [JSON]) ?? []
        options = values.filter { !string($0["id"]).isEmpty }.map { value in
            var value = value
            if result["seasons"] != nil { value["season"] = value["season"] ?? value["number"] }
            if result["episodes"] != nil { value["episode"] = value["episode"] ?? value["number"] }
            return value
        }.filter { value in
            let metadata = value["source558"] as? JSON
            let h = number(metadata?["height"]); let w = number(metadata?["width"])
            let title = string(value["title"]).lowercased()
            let ultra = title.range(of: "\\b(?:4k|8k|uhd|2160p|4320p)\\b", options: .regularExpression) != nil
            return h <= 1080 && w <= 1920 && !ultra && !title.contains("hevc") && !title.contains("x265")
        }.sorted { left, right in
            func preference(_ value: JSON) -> Int {
                let title = string(value["title"]).lowercased()
                return title.contains("720") ? 0 : title.contains("1080") ? 2 : 1
            }
            return preference(left) < preference(right)
        }
        if !options.isEmpty { progress = movie.kind == "tv" && episode == 0 ? "Выберите сезон или серию" : "Выберите раздачу. Предпочтительно 720p, H.264."; tableView.reloadData(); return }
        if let id = result["availability_id"] as? String { availability(id); return }
        if let url = Config.mediaURL(string(result["video_url"] ?? result["stream_url"] ?? result["source_url"])) {
            if download { showError("У этого источника нет совместимой офлайн-копии. Выберите другую раздачу.") }
            else { play(url) }; return
        }
        showError(string(result["note"]).isEmpty ? "Подходящий источник пока не найден." : string(result["note"]))
    }
    private func prepareDownload(_ links: JSON) {
        let choice = string(links["device_choice"] ?? links["torrent_ticket"])
        guard !choice.isEmpty else { showError("Источник не поддерживает офлайн-загрузку."); return }
        request("api/device-queue", method: "POST", body: ["action": "register", "choice": choice,
            "download_mode": "compatible", "capabilities": []]) { [weak self] entry in
            guard let self = self else { return }; let ref = string(entry["ref"])
            guard !ref.isEmpty else { self.showError("Не удалось создать загрузку."); return }
            self.expires = Date().addingTimeInterval(1800); self.resolve(ref)
        }
    }
    private func resolve(_ ref: String) {
        request("api/device-queue", method: "POST", body: ["action": "resolve", "ref": ref, "retry": false], timeout: 140) { [weak self] links in
            guard let self = self else { return }
            if links["pending"] as? Bool == true {
                self.progress = "Готовим совместимый MP4. Оставьте приложение открытым до начала загрузки."
                if links["preparation_percent"] != nil { self.progress += "\n" + string(links["preparation_percent"]) + "%" }
                self.tableView.reloadData(); self.later(5) { self.resolve(ref) }; return
            }
            do {
                let context = self.season > 0 && self.episode > 0 ? "s\(self.season)-e\(self.episode)" : ""
                if self.movie.kind == "tv" && context.isEmpty { throw failure("Сначала выберите конкретную серию.") }
                try OfflineStore.shared.enqueue(self.movie, links: links, context: context)
                self.progress = "Загрузка началась. Прогресс — во вкладке «Офлайн»."; self.tableView.reloadData()
            } catch { self.showError(error.localizedDescription) }
        }
    }
    private func startPlayback(_ links: JSON) {
        if let ticket = links["torrent_ticket"] as? String {
            route = "api/torrent-playback"
            createSession(["ticket": ticket, "position": 0, "capabilities": []])
        } else if let ticket = links["playback_ticket"] as? String {
            route = "api/playback"; createSession(["ticket": ticket, "position": 0])
        } else if let url = Config.mediaURL(string(links["video_url"] ?? links["stream_url"] ?? links["download_url"])) { play(url) }
        else { showError("Нет адреса видео.") }
    }
    private func createSession(_ body: JSON) {
        request(route, method: "POST", body: body) { [weak self] value in
            guard let self = self else { return }; self.sessionID = string(value["id"])
            guard !self.sessionID.isEmpty else { self.showError("Не удалось открыть видеопоток."); return }
            self.expires = Date().addingTimeInterval(180); self.pollSession()
        }
    }
    private func pollSession() {
        request(route + "/" + sessionID) { [weak self] value in
            guard let self = self else { return }; let state = string(value["status"] ?? value["state"])
            if ["failed", "error", "stopped"].contains(state) { self.showError(string(value["error"])); return }
            if ["ready", "playing"].contains(state), let url = Config.mediaURL(string(value["url"] ?? value["video_url"] ?? value["stream_url"])) {
                self.play(url); return
            }
            self.progress = "Подготавливаем видео…"; self.tableView.reloadData(); self.later(1.2) { self.pollSession() }
        }
    }
    private func play(_ url: URL) {
        let controller = LitePlayer(url: url, name: movie.title)
        controller.onClose = { [weak self] in
            self?.stop(); self?.navigationController?.popViewController(animated: true)
        }
        player = controller; present(controller, animated: true) { controller.player?.play() }
        if !sessionID.isEmpty {
            heartbeat = Timer.scheduledTimer(withTimeInterval: 6, repeats: true) { [weak self] _ in
                guard let self = self, !self.stopped else { return }
                API.shared.call(self.route + "/" + self.sessionID) { _, _ in }
                if self.route == "api/torrent-playback", let player = self.player?.player {
                    let seconds = CMTimeGetSeconds(player.currentTime())
                    if seconds.isFinite {
                        API.shared.call(self.route + "/" + self.sessionID + "/buffer449", method: "POST",
                            body: ["paused": player.rate == 0, "position": max(0, seconds)]) { _, _ in }
                    }
                }
            }
        }
    }
    override func numberOfSections(in tableView: UITableView) -> Int { return 2 }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { return section == 0 ? 1 + options.count : alternatives.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil); cell.backgroundColor = Theme.panel
        cell.textLabel?.textColor = .white; cell.textLabel?.numberOfLines = 0; cell.textLabel?.font = .systemFont(ofSize: 18)
        if indexPath.section == 0 && indexPath.row == 0 { cell.textLabel?.text = progress; cell.selectionStyle = .none }
        else {
            let row = indexPath.section == 0 ? options[indexPath.row - 1] : alternatives[indexPath.row]
            cell.textLabel?.text = string(row["title"] ?? row["label"] ?? row["name"])
            cell.accessoryType = .disclosureIndicator
        }
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard indexPath.section != 0 || indexPath.row > 0 else { return }
        let row = indexPath.section == 0 ? options[indexPath.row - 1] : alternatives[indexPath.row]
        if number(row["season"]) > 0 { season = Int(number(row["season"])) }
        if number(row["episode"]) > 0 { episode = Int(number(row["episode"])) }
        operation(string(row["id"]))
    }
    deinit { heartbeat?.invalidate(); task?.cancel() }
}

final class LitePlayer: AVPlayerViewController {
    var onClose: (() -> Void)?
    var onPosition: ((Double) -> Void)?
    private var periodic: Any?
    private var ended: NSObjectProtocol?
    private var reported = false
    private var observedItem: AVPlayerItem?
    init(url: URL, name: String, position: Double = 0) {
        super.init(nibName: nil, bundle: nil); title = name
        let cookies = HTTPCookieStorage.shared.cookies(for: url) ?? []
        let asset = AVURLAsset(url: url, options: [AVURLAssetHTTPCookiesKey: cookies])
        let item = AVPlayerItem(asset: asset); item.preferredPeakBitRate = 3_000_000
        player = AVPlayer(playerItem: item)
        observedItem = item; item.addObserver(self, forKeyPath: "status", options: [.new], context: nil)
        if position > 0 { player?.seek(to: CMTime(seconds: position, preferredTimescale: 600)) }
        allowsPictureInPicturePlayback = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func viewDidLoad() {
        super.viewDidLoad()
        try? AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
        try? AVAudioSession.sharedInstance().setActive(true)
        periodic = player?.addPeriodicTimeObserver(forInterval: CMTime(seconds: 10, preferredTimescale: 1), queue: .main) { [weak self] time in
            let seconds = CMTimeGetSeconds(time); if seconds.isFinite { self?.onPosition?(seconds) }
        }
        ended = NotificationCenter.default.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: player?.currentItem, queue: .main) { [weak self] _ in
            self?.message("Воспроизведение прервано. Закройте плеер и выберите другую раздачу.")
        }
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if isBeingDismissed || presentingViewController == nil {
            player?.pause()
            if let time = player?.currentTime() { let seconds = CMTimeGetSeconds(time); if seconds.isFinite { onPosition?(seconds) } }
            if !reported { reported = true; onClose?() }
        }
    }
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) {
        guard keyPath == "status", let item = object as? AVPlayerItem else {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context); return
        }
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            if item.status == .failed { self.player?.pause(); self.message("Не удалось воспроизвести видео. Выберите другую раздачу H.264 до Full HD.") }
            if item.status == .readyToPlay {
                let size = item.presentationSize
                if max(size.width, size.height) > 1920 || min(size.width, size.height) > 1080 {
                    self.player?.pause(); self.message("Видео выше Full HD не подходит этой версии приложения. Выберите 720p или 1080p.")
                }
            }
        }
    }
    deinit {
        observedItem?.removeObserver(self, forKeyPath: "status")
        if let periodic = periodic { player?.removeTimeObserver(periodic) }
        if let ended = ended { NotificationCenter.default.removeObserver(ended) }
    }
}
