import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate, UITabBarControllerDelegate {
    var window: UIWindow?
    private(set) var authenticated = false
    private var touched = false
    private var checking = false
    private var tabs: UITabBarController!
    static var current: AppDelegate { return UIApplication.shared.delegate as! AppDelegate }
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Theme.setup(); CookieVault.shared.restore()
        URLCache.shared = URLCache(memoryCapacity: 4 * 1024 * 1024, diskCapacity: 32 * 1024 * 1024, diskPath: "posters740")
        let controllers: [LibraryController] = [LibraryController(.catalog), LibraryController(.search), LibraryController(.list), LibraryController(.offline)]
        let icons: [UITabBarItem.SystemItem] = [.featured, .search, .bookmarks, .downloads]
        let labels = ["Каталог", "Поиск", "Мой список", "Офлайн"]
        tabs = UITabBarController(); tabs.delegate = self
        tabs.viewControllers = controllers.enumerated().map { index, controller in
            controller.onTouched = { [weak self] in self?.touched = true }
            let nav = UINavigationController(rootViewController: controller)
            nav.tabBarItem = UITabBarItem(tabBarSystemItem: icons[index], tag: index); nav.tabBarItem.title = labels[index]
            return nav
        }
        // Local files and posters render before the first network request or login.
        tabs.selectedIndex = 3
        window = UIWindow(frame: UIScreen.main.bounds); window?.rootViewController = tabs; window?.makeKeyAndVisible()
        OfflineStore.shared.activate()
        checkSession(automatic: true)
        return true
    }
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) { touched = true }
    func checkSession(automatic: Bool = false) {
        guard !checking else { return }; checking = true
        API.shared.call("api/session", timeout: 8) { [weak self] value, _ in
            guard let self = self else { return }
            self.checking = false
            guard value?["authenticated"] as? Bool == true, let user = value?["user"] as? JSON else {
                self.authenticated = false; return
            }
            self.authenticated = true
            let owner = string(user["id"] ?? user["user_id"])
            let changed = OfflineStore.shared.owner != owner
            if changed {
                Posters.shared.clear(); self.tabs.dismiss(animated: false)
                (self.tabs.viewControllers ?? []).forEach { controller in
                    let nav = controller as? UINavigationController
                    nav?.popToRootViewController(animated: false)
                    (nav?.viewControllers.first as? LibraryController)?.ownerChanged()
                }
            }
            OfflineStore.shared.switchOwner(owner)
            if automatic && !self.touched { self.tabs.selectedIndex = 0 }
            let nav = self.tabs.selectedViewController as? UINavigationController
            (nav?.viewControllers.first as? LibraryController)?.reload()
        }
    }
    func applicationDidBecomeActive(_ application: UIApplication) { checkSession() }
    func applicationDidEnterBackground(_ application: UIApplication) { CookieVault.shared.save() }
    func applicationDidReceiveMemoryWarning(_ application: UIApplication) { Posters.shared.clear() }
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String,
                     completionHandler: @escaping () -> Void) {
        guard identifier == Config.bundle + ".downloads" else { completionHandler(); return }
        OfflineStore.shared.backgroundCompletion = completionHandler; OfflineStore.shared.activate()
    }
}

final class LoginController: UIViewController {
    private let stack = UIStackView()
    private let status = Theme.label(20)
    private let code = Theme.label(42, bold: true)
    private var link: URL?
    private var id = ""
    private var expires = Date()
    private var revision = 0
    private var task: URLSessionDataTask?
    private var confirmedUser: JSON?
    private lazy var openButton = Theme.button("Открыть Telegram", target: self, action: #selector(openTelegram))
    private lazy var finishButton = Theme.button("Подтвердить вход", target: self, action: #selector(finish))
    override func viewDidLoad() {
        super.viewDidLoad(); title = "Вход в Медиатеку"; view.backgroundColor = Theme.background
        stack.axis = .vertical; stack.spacing = 24; stack.alignment = .fill
        view.addSubview(stack); stack.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor), stack.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.75)])
        status.textAlignment = .center; code.textAlignment = .center; code.textColor = Theme.accent
        [status, code, openButton, finishButton, Theme.button("Новый код", target: self, action: #selector(start))].forEach(stack.addArrangedSubview)
        finishButton.isHidden = true; start()
    }
    @objc private func start() {
        task?.cancel(); revision += 1; confirmedUser = nil; link = nil; finishButton.isHidden = true; code.text = ""
        let token = revision; status.text = "Создаём код для входа…"
        task = API.shared.call("auth/device/start", method: "POST", body: [:]) { [weak self] value, error in
            guard let self = self, self.revision == token else { return }
            if let error = error { self.status.text = error.localizedDescription; return }
            guard let value = value, let url = URL(string: string(value["url"])), url.scheme == "https",
                ["t.me", "telegram.me"].contains(url.host ?? "") else { self.status.text = "Не удалось получить ссылку входа."; return }
            self.id = string(value["id"]); self.link = url; self.code.text = string(value["code"])
            self.expires = Date().addingTimeInterval(number(value["expires_in"]))
            self.status.text = "Откройте бота, подтвердите этот код и вернитесь в приложение."; self.poll(token)
        }
    }
    private func poll(_ token: Int) {
        guard revision == token, isViewLoaded else { return }
        if Date() > expires { status.text = "Код истёк. Создайте новый."; return }
        task = API.shared.call("auth/device/status", method: "POST", body: ["id": id]) { [weak self] value, error in
            guard let self = self, self.revision == token else { return }
            if let error = error { self.status.text = error.localizedDescription; return }
            let state = string(value?["status"])
            if state == "denied" { self.status.text = "Вход отклонён."; return }
            if state == "approved", let user = value?["user"] as? JSON {
                self.confirmedUser = user; self.finishButton.isHidden = false
                self.status.text = "Войти как " + string(user["first_name"]) + " " + string(user["last_name"]) + "?"; return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in self?.poll(token) }
        }
    }
    @objc private func openTelegram() { if let link = link { UIApplication.shared.open(link, options: [:], completionHandler: nil) } }
    @objc private func finish() {
        guard confirmedUser != nil else { return }; finishButton.isEnabled = false
        task = API.shared.call("auth/device/finish", method: "POST", body: ["id": id]) { [weak self] _, error in
            guard let self = self else { return }; self.finishButton.isEnabled = true
            if let error = error { self.status.text = error.localizedDescription; return }
            CookieVault.shared.save(); AppDelegate.current.checkSession()
            self.navigationController?.popViewController(animated: true)
        }
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated); if isMovingFromParent { revision += 1; task?.cancel() }
    }
    deinit { task?.cancel() }
}
