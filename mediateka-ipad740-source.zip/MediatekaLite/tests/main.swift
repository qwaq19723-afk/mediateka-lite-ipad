import Foundation

var checks = 0
func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
    checks += 1
    if !condition() { fputs("FAILED: " + message + "\n", stderr); exit(1) }
}
expect(Config.mediaURL("api/session")?.path == "/mediabot/api/session", "relative API origin")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/mediabot/file.mp4") != nil, "same origin file")
expect(Config.mediaURL("http://panelfreak.zyxcloud.xyz/mediabot/file.mp4") == nil, "TLS required")
expect(Config.mediaURL("https://elsewhere.invalid/mediabot/file.mp4") == nil, "foreign origin denied")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/admin/") == nil, "outside application denied")
expect(Config.mediaURL("https://name:secret@panelfreak.zyxcloud.xyz/mediabot/file") == nil, "userinfo denied")
expect(Config.mediaURL("https://panelfreak.zyxcloud.xyz/mediabot/%2e%2e/private") == nil, "encoded traversal denied")
expect(Movie(["id":"../../bad","kind":"movie"]) == nil, "invalid identity denied")
let movie = Movie(["id":238,"kind":"movie","title":"Крёстный отец","year":1972,
    "choice":"PRIVATE","torrent_ticket":"PRIVATE","stream_url":"PRIVATE","cover":"poster.jpg"])!
expect(movie.key == "movie-238", "stable movie identity")
expect(movie.display["choice"] == nil && movie.display["torrent_ticket"] == nil && movie.display["stream_url"] == nil, "no playable credentials in cached metadata")
expect(Movie(["id":1,"media_type":"series"])?.kind == "tv", "series identity")
expect(movie.title == "Крёстный отец" && movie.year == "1972", "Russian text and number normalization")
print("Model checks passed: \(checks)")
