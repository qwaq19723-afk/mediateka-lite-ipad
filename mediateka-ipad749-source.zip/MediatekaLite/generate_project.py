"""Deterministic Xcode 13 project; Python stdlib only, no third-party build plugins."""
import hashlib
import json
import plistlib
from pathlib import Path
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent
APP = ROOT / 'MediatekaLite'
PROJECT = ROOT / 'MediatekaLite.xcodeproj'
PROJECT.mkdir(exist_ok=True)

def uid(text): return hashlib.sha256(text.encode()).hexdigest()[:24].upper()
def quote(value): return json.dumps(value, ensure_ascii=False)
objects = {}
def add(key, body):
    ident = uid(key); objects[ident] = body; return ident
sources = sorted(APP.glob('*.swift'))
source_refs = [add('ref:'+p.name, 'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = '+quote(p.name)+'; sourceTree = "<group>";') for p in sources]
build_refs = [add('build:'+p.name, 'isa = PBXBuildFile; fileRef = '+r+';') for p,r in zip(sources,source_refs)]
resource_refs, resource_builds = [], []
for name, kind in [('Assets.xcassets','folder.assetcatalog'),('LaunchScreen.storyboard','file.storyboard')]:
    r=add('ref:'+name, 'isa = PBXFileReference; lastKnownFileType = '+kind+'; path = '+quote(name)+'; sourceTree = "<group>";')
    resource_refs.append(r); resource_builds.append(add('build:'+name,'isa = PBXBuildFile; fileRef = '+r+';'))
def listing(values): return '('+','.join(values)+',)'
app_ref=add('product','isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = MediatekaLite.app; sourceTree = BUILT_PRODUCTS_DIR;')
source_group=add('sourcegroup','isa = PBXGroup; children = '+listing(source_refs+resource_refs)+'; path = MediatekaLite; sourceTree = "<group>";')
products=add('products','isa = PBXGroup; children = '+listing([app_ref])+'; name = Products; sourceTree = "<group>";')
main=add('main','isa = PBXGroup; children = '+listing([source_group,products])+'; sourceTree = "<group>";')
phase=add('sources','isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = '+listing(build_refs)+'; runOnlyForDeploymentPostprocessing = 0;')
resources=add('resources','isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = '+listing(resource_builds)+'; runOnlyForDeploymentPostprocessing = 0;')
frameworks=add('frameworks','isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = (); runOnlyForDeploymentPostprocessing = 0;')
settings={
 'IPHONEOS_DEPLOYMENT_TARGET':'10.0','SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','ARCHS':'arm64',
 'TARGETED_DEVICE_FAMILY':'2','SUPPORTS_MACCATALYST':'NO','PRODUCT_BUNDLE_IDENTIFIER':'xyz.zyxcloud.mediateka.lite',
 'PRODUCT_NAME':'$(TARGET_NAME)','INFOPLIST_FILE':'MediatekaLite/Info.plist','ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon',
 'CURRENT_PROJECT_VERSION':'6','MARKETING_VERSION':'0.1.4','ENABLE_BITCODE':'NO','CLANG_ENABLE_MODULES':'YES',
 'ALWAYS_EMBED_SWIFT_STANDARD_LIBRARIES':'YES','LD_RUNPATH_SEARCH_PATHS':'$(inherited) @executable_path/Frameworks',
 'SWIFT_STRICT_CONCURRENCY':'minimal','CODE_SIGN_STYLE':'Automatic','GENERATE_INFOPLIST_FILE':'NO',
 'SWIFT_EMIT_LOC_STRINGS':'NO','SWIFT_OPTIMIZATION_LEVEL':'-O','DEBUG_INFORMATION_FORMAT':'dwarf-with-dsym',
}
configs=[]
for name in ['Debug','Release']:
    local=dict(settings)
    if name=='Debug':local.update(SWIFT_OPTIMIZATION_LEVEL='-Onone',ENABLE_TESTABILITY='YES')
    text=' '.join(quote(k)+' = '+quote(v)+';' for k,v in local.items())
    configs.append(add('config:'+name,'isa = XCBuildConfiguration; buildSettings = { '+text+' }; name = '+name+';'))
config_list=add('configs','isa = XCConfigurationList; buildConfigurations = '+listing(configs)+'; defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
target=add('target','isa = PBXNativeTarget; buildConfigurationList = '+config_list+'; buildPhases = '+listing([phase,frameworks,resources])+'; buildRules = (); dependencies = (); name = MediatekaLite; productName = MediatekaLite; productReference = '+app_ref+'; productType = "com.apple.product-type.application";')
project=add('project','isa = PBXProject; attributes = { LastUpgradeCheck = 1340; }; buildConfigurationList = '+config_list+'; compatibilityVersion = "Xcode 12.0"; developmentRegion = ru; hasScannedForEncodings = 0; knownRegions = (ru,en,Base,); mainGroup = '+main+'; productRefGroup = '+products+'; projectDirPath = ""; projectRoot = ""; targets = '+listing([target])+';')
(PROJECT/'project.pbxproj').write_text('// !$*UTF8*$!\n{ archiveVersion = 1; classes = {}; objectVersion = 54; objects = {\n'+''.join(k+' = { '+v+' };\n' for k,v in objects.items())+'}; rootObject = '+project+'; }\n',encoding='utf-8')
schemes=PROJECT/'xcshareddata/xcschemes';schemes.mkdir(parents=True,exist_ok=True)
(schemes/'MediatekaLite.xcscheme').write_text('''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1340" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="'''+target+'''" BuildableName="MediatekaLite.app" BlueprintName="MediatekaLite" ReferencedContainer="container:MediatekaLite.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><LaunchAction buildConfiguration="Debug" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="'''+target+'''" BuildableName="MediatekaLite.app" BlueprintName="MediatekaLite" ReferencedContainer="container:MediatekaLite.xcodeproj"/></BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>
''',encoding='utf-8')
info={
 'CFBundleDevelopmentRegion':'ru','CFBundleDisplayName':'Медиатека','CFBundleExecutable':'$(EXECUTABLE_NAME)',
 'CFBundleIdentifier':'$(PRODUCT_BUNDLE_IDENTIFIER)','CFBundleInfoDictionaryVersion':'6.0',
 'CFBundleName':'Медиатека Lite','CFBundlePackageType':'APPL','CFBundleShortVersionString':'$(MARKETING_VERSION)',
 'CFBundleVersion':'$(CURRENT_PROJECT_VERSION)','LSRequiresIPhoneOS':True,'MinimumOSVersion':'10.0',
 'UIDeviceFamily':[2],'UIRequiredDeviceCapabilities':['arm64'],'UILaunchStoryboardName':'LaunchScreen',
 'UIStatusBarStyle':'UIStatusBarStyleLightContent','UIViewControllerBasedStatusBarAppearance':False,
 'UIRequiresFullScreen':True,'UIBackgroundModes':['audio'],
 'UISupportedInterfaceOrientations~ipad':['UIInterfaceOrientationPortrait','UIInterfaceOrientationPortraitUpsideDown','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'],
 'NSAppTransportSecurity':{'NSAllowsArbitraryLoads':False},'ITSAppUsesNonExemptEncryption':False,
}
(APP/'Info.plist').write_bytes(plistlib.dumps(info,sort_keys=True))
print(json.dumps({'project':str(PROJECT),'swift_files':len(sources),'deployment':'10.0','architectures':['arm64'],'device_family':[2]}))
