import UIKit

final class DetailController: UIViewController {
    private var movie: Movie
    private let scroll = UIScrollView()
    private let stack = UIStackView()
    private let titleLabel = Theme.label(28, bold: true)
    private let metadata = Theme.label(16)
    private let overview = Theme.label(19)
    private let people = Theme.label(16)
    private let poster = UIImageView()
    private var task: URLSessionDataTask?
    init(_ movie: Movie) { self.movie = movie; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func viewDidLoad() {
        super.viewDidLoad(); title = movie.title; view.backgroundColor = Theme.background
        scroll.alwaysBounceVertical = true; view.addSubview(scroll)
        stack.axis = .vertical; stack.spacing = 16; stack.alignment = .fill; stack.translatesAutoresizingMaskIntoConstraints = false; scroll.addSubview(stack)
        NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: scroll.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: scroll.trailingAnchor, constant: -24), stack.topAnchor.constraint(equalTo: scroll.topAnchor, constant: 20),
            stack.bottomAnchor.constraint(equalTo: scroll.bottomAnchor, constant: -28), stack.widthAnchor.constraint(equalTo: scroll.widthAnchor, constant: -48)])
        poster.contentMode = .scaleAspectFit; poster.heightAnchor.constraint(equalToConstant: 300).isActive = true
        let actions = UIStackView(); actions.axis = .horizontal; actions.spacing = 12; actions.distribution = .fillEqually
        actions.addArrangedSubview(Theme.button("▶ Смотреть", target: self, action: #selector(watch)))
        actions.addArrangedSubview(Theme.button("↓ Скачать офлайн", target: self, action: #selector(download)))
        [poster, titleLabel, metadata, actions, Theme.button("+ В мой список", target: self, action: #selector(bookmark)), overview, people].forEach(stack.addArrangedSubview)
        metadata.textColor = Theme.muted; people.textColor = Theme.muted
        render()
        task = API.shared.call("api/atv/detail/" + movie.kind + "/" + movie.id, timeout: 30) { [weak self] value, error in
            guard let self = self else { return }
            if let value = value, let fresh = Movie(value) { self.movie = fresh; self.render() }
            else if let error = error, self.movie.overview.isEmpty { self.overview.text = error.localizedDescription }
        }
    }
    override func viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); scroll.frame = view.bounds }
    private func render() {
        titleLabel.text = movie.title; metadata.text = movie.year + (movie.kind == "tv" ? " · Сериал" : " · Фильм")
        overview.text = movie.overview.isEmpty ? "Описание пока не добавлено." : movie.overview
        func names(_ value: Any?) -> String {
            if let text = value as? String { return text }
            if let list = value as? [String] { return list.joined(separator: ", ") }
            if let list = value as? [JSON] { return list.map { string($0["name"]) }.filter { !$0.isEmpty }.joined(separator: ", ") }
            return ""
        }
        let directors = names(movie.raw["directors"] ?? movie.raw["director"])
        let actors = names(movie.raw["cast"] ?? movie.raw["actors"])
        people.text = (directors.isEmpty ? "" : "Режиссёр: " + directors) + (actors.isEmpty ? "" : "\nВ ролях: " + actors)
        Posters.shared.load(movie.poster, into: poster)
    }
    @objc private func watch() { navigationController?.pushViewController(PlaybackFlow(movie: movie, download: false), animated: true) }
    @objc private func download() { navigationController?.pushViewController(PlaybackFlow(movie: movie, download: true), animated: true) }
    @objc private func bookmark() {
        guard let body = movie.bookmarkPayload else { message("Не удалось определить фильм. Откройте карточку заново."); return }
        API.shared.call("api/atv/list", method: "POST", body: body) { [weak self] _, error in
            self?.message(error?.localizedDescription ?? "Добавлено в мой список.")
        }
    }
    deinit { task?.cancel() }
}
