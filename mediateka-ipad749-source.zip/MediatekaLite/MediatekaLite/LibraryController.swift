import UIKit

final class PosterCell: UICollectionViewCell {
    let image = UIImageView()
    let name = Theme.label(17, bold: true)
    let note = Theme.label(13)
    let progress = UIProgressView(progressViewStyle: .default)
    override init(frame: CGRect) {
        super.init(frame: frame); backgroundColor = Theme.panel; layer.cornerRadius = 12; clipsToBounds = true
        image.contentMode = .scaleAspectFill; image.clipsToBounds = true
        note.textColor = Theme.muted; name.numberOfLines = 2; note.numberOfLines = 1
        progress.progressTintColor = Theme.accent; progress.isHidden = true
        [image, name, note, progress].forEach(contentView.addSubview)
        isAccessibilityElement = true
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func layoutSubviews() {
        super.layoutSubviews(); let width = contentView.bounds.width; let height = max(100, contentView.bounds.height - (note.numberOfLines == 2 ? 100 : 72))
        image.frame = CGRect(x: 0, y: 0, width: width, height: height)
        name.frame = CGRect(x: 10, y: height + 7, width: width - 20, height: 40)
        note.frame = CGRect(x: 10, y: height + 49, width: width - 20, height: note.numberOfLines == 2 ? 35 : 17)
        progress.frame = CGRect(x: 10, y: contentView.bounds.height - 10, width: width - 20, height: 3)
    }
    override func prepareForReuse() { super.prepareForReuse(); image.accessibilityIdentifier = nil; image.image = nil; name.text = nil; note.text = nil; note.numberOfLines = 1; progress.isHidden = true }
}

final class LibraryController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    enum Mode { case catalog, search, list, offline }
    let mode: Mode
    private let flow = UICollectionViewFlowLayout()
    private lazy var collection = UICollectionView(frame: .zero, collectionViewLayout: flow)
    private let search = UISearchBar()
    private let sections = UISegmentedControl(items: ["Фильмы", "Сериалы"])
    private let sorting = UISegmentedControl(items: ["Новые", "Популярные"])
    private let status = Theme.label(15)
    private var movies: [Movie] = []
    private var offlineRows: [JSON] = []
    private var page = 1
    private var more = false
    private var busy = false
    private var revision = 0
    private var task: URLSessionDataTask?
    private var observer: NSObjectProtocol?
    private var sessionObserver: NSObjectProtocol?
    private let refresh = UIRefreshControl()
    var onTouched: (() -> Void)?
    init(_ mode: Mode) { self.mode = mode; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not used") }
    override func viewDidLoad() {
        super.viewDidLoad(); view.backgroundColor = Theme.background
        title = mode == .catalog ? "Главная" : mode == .search ? "Поиск" : mode == .list ? "Мой список" : "Загрузки"
        collection.backgroundColor = Theme.background; collection.alwaysBounceVertical = true
        collection.register(PosterCell.self, forCellWithReuseIdentifier: "poster"); collection.dataSource = self; collection.delegate = self
        flow.minimumLineSpacing = 16; flow.minimumInteritemSpacing = 14; flow.sectionInset = UIEdgeInsets(top: 8, left: 16, bottom: 20, right: 16)
        collection.refreshControl = refresh; refresh.addTarget(self, action: #selector(reload), for: .valueChanged)
        status.textColor = Theme.muted; view.addSubview(status); view.addSubview(collection)
        if mode == .search { search.delegate = self; search.placeholder = "Название фильма или сериала"; search.barStyle = .black; view.addSubview(search) }
        if mode == .catalog {
            for control in [sections, sorting] {
                control.selectedSegmentIndex = 0; control.tintColor = Theme.accent
                control.addTarget(self, action: #selector(catalogChanged), for: .valueChanged); view.addSubview(control)
            }
        }
        if mode == .offline {
            observer = NotificationCenter.default.addObserver(forName: OfflineStore.changed, object: nil, queue: .main) { [weak self] _ in self?.renderOffline() }
            renderOffline()
        }
        sessionObserver = NotificationCenter.default.addObserver(forName: AppDelegate.sessionChanged, object: nil, queue: .main) { [weak self] _ in self?.sessionUpdated() }
        sessionUpdated()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sessionUpdated()
        if mode == .offline { renderOffline() }
        else if AppDelegate.current.authenticated && movies.isEmpty && mode != .search { reload() }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews(); let width = view.bounds.width; var y: CGFloat = 8
        if mode == .search { search.frame = CGRect(x: 8, y: y, width: width - 16, height: 52); y += 58 }
        if mode == .catalog {
            let half = (width - 48) / 2
            sections.frame = CGRect(x: 16, y: y, width: half, height: 42)
            sorting.frame = CGRect(x: 32 + half, y: y, width: half, height: 42); y += 50
        }
        status.frame = CGRect(x: 16, y: y, width: width - 32, height: 42); y += 44
        collection.frame = CGRect(x: 0, y: y, width: width, height: max(0, view.bounds.height - y))
        flow.invalidateLayout()
    }
    @objc private func login() { navigationController?.pushViewController(LoginController(), animated: true) }
    @objc private func catalogChanged() { movies = []; collection.reloadData(); reload() }
    @objc private func retryConnection() { AppDelegate.current.checkSession(); status.text = "Проверяем подключение…" }
    private func sessionUpdated() {
        let app = AppDelegate.current
        let needsLogin = app.serverReachable && !app.authenticated
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: needsLogin ? "Войти" : "Проверить связь", style: .plain,
            target: self, action: needsLogin ? #selector(login) : #selector(retryConnection))
        if mode == .offline { renderOffline() }
        else if !app.authenticated { status.text = app.sessionMessage }
    }
    func ownerChanged() {
        task?.cancel(); revision += 1; busy = false; movies = []; offlineRows = []; more = false; page = 1
        if isViewLoaded { collection.reloadData(); if mode == .offline { renderOffline() } }
    }
    @objc func reload() {
        onTouched?(); task?.cancel(); revision += 1; busy = false; page = 1; more = false
        if mode == .offline { renderOffline(); refresh.endRefreshing(); return }
        guard AppDelegate.current.authenticated else { status.text = AppDelegate.current.sessionMessage; refresh.endRefreshing(); return }
        if mode == .search && (search.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { status.text = "Введите название и нажмите «Найти»."; refresh.endRefreshing(); return }
        loadPage()
    }
    private func loadPage() {
        guard !busy else { return }; busy = true; status.text = "Загружаем…"; let token = revision
        let path: String
        switch mode {
        case .catalog: path = CatalogSection.path(series: sections.selectedSegmentIndex == 1, popular: sorting.selectedSegmentIndex == 1, page: page)
        case .search: path = "api/atv/search?q=" + API.query(search.text ?? "")
        case .list: path = "api/atv/list"
        case .offline: return
        }
        task = API.shared.call(path, timeout: 55) { [weak self] value, error in
            guard let self = self, self.revision == token else { return }; self.busy = false; self.refresh.endRefreshing()
            if let error = error { self.status.text = error.localizedDescription; return }
            let raw = value?["items"] as? [JSON] ?? []
            let incoming = raw.compactMap(Movie.init)
            if self.page == 1 { self.movies = incoming } else {
                let known = Set(self.movies.map { $0.key }); self.movies += incoming.filter { !known.contains($0.key) }
            }
            self.more = self.mode == .catalog && !incoming.isEmpty && (value?["more"] as? Bool ?? value?["has_more"] as? Bool ?? (incoming.count >= 20))
            self.page += 1; self.status.text = self.movies.isEmpty ? "Ничего не найдено. Попробуйте другое название." : "\(self.movies.count) · Фильмы и сериалы"
            self.collection.reloadData()
        }
    }
    private func renderOffline() {
        offlineRows = OfflineStore.shared.rows
        let waiting = DownloadQueue.pending(offlineRows)
        for i in offlineRows.indices {
            if let position = waiting.firstIndex(where: { string($0["key"]) == string(offlineRows[i]["key"]) }) {
                offlineRows[i]["queue_position"] = position + 1
            }
        }
        let active = offlineRows.filter(DownloadDisplay.isActive).count
        let pending = active + waiting.count
        tabBarItem.badgeValue = pending > 0 ? String(pending) : nil
        navigationController?.tabBarItem.badgeValue = pending > 0 ? String(pending) : nil
        status.text = offlineRows.isEmpty ? (AppDelegate.current.authenticated ?
            "Скачайте фильм или серию заранее — они появятся здесь с постерами." : AppDelegate.current.sessionMessage) :
            "Готово · \(offlineRows.filter { string($0["state"]) == "ready" }.count)    В процессе · \(active)    В очереди · \(waiting.count)"
        collection.reloadData()
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) { searchBar.resignFirstResponder(); reload() }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int { return mode == .offline ? offlineRows.count : movies.count }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "poster", for: indexPath) as! PosterCell
        if mode == .offline {
            let row = offlineRows[indexPath.item]; let movie = Movie(row["movie"] as? JSON ?? [:])
            cell.image.image = OfflineStore.shared.poster(row); cell.name.text = movie?.title
            cell.note.numberOfLines = 2; cell.note.text = DownloadDisplay.note(row)
            if let fraction = DownloadDisplay.fraction(row) { cell.progress.isHidden = false; cell.progress.progress = fraction }
            else { cell.progress.isHidden = true }
        } else {
            let movie = movies[indexPath.item]; cell.name.text = movie.title; cell.note.text = movie.year + (movie.kind == "tv" ? " · Сериал" : " · Фильм")
            Posters.shared.load(movie.poster, into: cell.image)
        }
        cell.accessibilityLabel = (cell.name.text ?? "") + ". " + (cell.note.text ?? "")
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let columns: CGFloat = view.bounds.width > view.bounds.height ? 5 : 3
        let width = floor((collectionView.bounds.width - 32 - (columns - 1) * 14) / columns)
        return CGSize(width: width, height: width * 1.5 + (mode == .offline ? 100 : 72))
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if scrollView.isDragging { onTouched?() }
        if more && !busy && scrollView.contentOffset.y + scrollView.bounds.height > scrollView.contentSize.height - 450 { loadPage() }
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        onTouched?()
        if mode != .offline { navigationController?.pushViewController(DetailController(movies[indexPath.item]), animated: true); return }
        let row = offlineRows[indexPath.item]; let key = string(row["key"])
        let sheet = UIAlertController(title: Movie(row["movie"] as? JSON ?? [:])?.title,
            message: DownloadDisplay.note(row) + (string(row["state"]) == "preparing" ? "\n" + string(row["note"]) : ""), preferredStyle: .actionSheet)
        if string(row["state"]) == "ready", let file = OfflineStore.shared.file(row) {
            sheet.addAction(UIAlertAction(title: "Смотреть офлайн", style: .default) { [weak self] _ in
                let player = LitePlayer(url: file, name: Movie(row["movie"] as? JSON ?? [:])?.title ?? "Фильм", position: number(row["position"]))
                let owner = OfflineStore.shared.owner
                player.onPosition = { seconds in if OfflineStore.shared.owner == owner { OfflineStore.shared.position(key, seconds: seconds) } }
                self?.present(player, animated: true) { player.player?.play() }
            })
        } else if DownloadQueue.containsJob(row) && string(row["state"]) != "verifying" {
            sheet.addAction(UIAlertAction(title: "Приостановить", style: .default) { _ in OfflineStore.shared.pause(key) })
        } else if string(row["state"]) != "verifying" {
            sheet.addAction(UIAlertAction(title: "Продолжить подготовку", style: .default) { [weak self] _ in
                guard AppDelegate.current.authenticated else { self?.message("Для продолжения загрузки нужен интернет и вход в Медиатеку."); return }
                if !string(row["ref"]).isEmpty {
                    do { try OfflineStore.shared.resumePreparation(key) }
                    catch { self?.message(error.localizedDescription) }; return
                }
                guard let movie = Movie(row["movie"] as? JSON ?? [:]) else { return }
                self?.navigationController?.pushViewController(PlaybackFlow(movie: movie, download: true), animated: true)
            })
            sheet.addAction(UIAlertAction(title: "Выбрать другую раздачу до 720p", style: .default) { [weak self] _ in
                guard AppDelegate.current.authenticated else { self?.message("Для выбора раздачи нужен интернет и вход в Медиатеку."); return }
                guard let movie = Movie(row["movie"] as? JSON ?? [:]) else { return }
                self?.navigationController?.pushViewController(PlaybackFlow(movie: movie, download: true), animated: true)
            })
        }
        sheet.addAction(UIAlertAction(title: "Удалить с iPad", style: .destructive) { _ in OfflineStore.shared.remove(key) })
        sheet.addAction(UIAlertAction(title: "Отмена", style: .cancel))
        sheet.popoverPresentationController?.sourceView = collectionView.cellForItem(at: indexPath)
        sheet.popoverPresentationController?.sourceRect = collectionView.cellForItem(at: indexPath)?.bounds ?? .zero
        present(sheet, animated: true)
    }
    deinit {
        task?.cancel()
        if let observer = observer { NotificationCenter.default.removeObserver(observer) }
        if let observer = sessionObserver { NotificationCenter.default.removeObserver(observer) }
    }
}
