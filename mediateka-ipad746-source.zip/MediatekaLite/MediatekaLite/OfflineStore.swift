import Foundation
import AVFoundation
import CoreMedia
import UIKit
import ImageIO
import AudioToolbox

final class OfflineStore: NSObject, URLSessionDownloadDelegate {
    static let shared = OfflineStore()
    static let changed = Notification.Name("OfflineChanged740")
    private(set) var owner = UserDefaults.standard.string(forKey: "lastOwner740") ?? ""
    private(set) var rows: [JSON] = []
    var backgroundCompletion: (() -> Void)?
    private var lastSave = Date.distantPast
    private var preparations: [String: UUID] = [:]
    private var preparationRequests: [String: URLSessionDataTask] = [:]
    private let manager = FileManager.default
    private lazy var root: URL = {
        let base = manager.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Offline740", isDirectory: true)
        try? manager.createDirectory(at: base, withIntermediateDirectories: true)
        var folder = base; var values = URLResourceValues(); values.isExcludedFromBackup = true
        try? folder.setResourceValues(values)
        return folder
    }()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.background(withIdentifier: Config.bundle + ".downloads")
        config.httpCookieStorage = HTTPCookieStorage.shared; config.httpShouldSetCookies = true
        config.httpMaximumConnectionsPerHost = 1; config.allowsCellularAccess = false
        config.isDiscretionary = false; config.sessionSendsLaunchEvents = true
        return URLSession(configuration: config, delegate: self, delegateQueue: OperationQueue.main)
    }()
    private var directory: URL { return root.appendingPathComponent(owner.isEmpty ? "none" : owner, isDirectory: true) }
    override init() { super.init(); read() }
    func activate() {
        let scope = owner
        let snapshot = rows
        session.getAllTasks { tasks in DispatchQueue.main.async {
            guard self.owner == scope else { return }
            let active = Set(tasks.compactMap { $0.taskDescription })
            for index in self.rows.indices where string(self.rows[index]["state"]) == "downloading" {
                let key = string(self.rows[index]["key"])
                guard snapshot.contains(where: { string($0["key"]) == key && string($0["state"]) == "downloading" &&
                    string($0["task_id"]) == string(self.rows[index]["task_id"]) }) else { continue }
                if !active.contains(self.owner + "|" + string(self.rows[index]["key"])) {
                    self.rows[index]["state"] = "paused"; self.rows[index]["note"] = "Продолжите загрузку."
                }
            }
            self.save()
        }}
        if AppDelegate.current.authenticated {
            for row in rows where string(row["state"]) == "preparing" && !string(row["ref"]).isEmpty {
                let key = string(row["key"])
                if preparations[key] == nil {
                    let token = UUID(); preparations[key] = token
                    resolve(key, token: token, scope: scope, until: Date().addingTimeInterval(4 * 3600))
                }
            }
        }
    }
    func switchOwner(_ value: String) {
        guard value.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return }
        if owner != value {
            preparationRequests.values.forEach { $0.cancel() }
            preparationRequests.removeAll(); preparations.removeAll()
            let previous = owner + "|"
            session.getAllTasks { tasks in tasks.filter { $0.taskDescription?.hasPrefix(previous) == true }.forEach { $0.cancel() } }
            owner = value; UserDefaults.standard.set(value, forKey: "lastOwner740"); read(); save()
        }
        activate()
    }
    private func read() {
        guard owner.isEmpty || owner.range(of: "^[0-9]+$", options: .regularExpression) != nil else { owner = ""; rows = []; return }
        guard let data = try? Data(contentsOf: directory.appendingPathComponent("index.json")),
            let value = (try? JSONSerialization.jsonObject(with: data)) as? JSON,
            string(value["owner"]) == owner, number(value["schema"]) == 1,
            let list = value["items"] as? [JSON] else { rows = []; return }
        rows = list.filter { row in
            let key = string(row["key"])
            return key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil
        }
        for i in rows.indices where string(rows[i]["state"]) == "ready" {
            if file(rows[i]) == nil { rows[i]["state"] = "error"; rows[i]["note"] = "Файл отсутствует или повреждён." }
        }
        for i in rows.indices where string(rows[i]["state"]) == "verifying" ||
            (string(rows[i]["state"]) == "preparing" && string(rows[i]["ref"]).isEmpty) {
            rows[i]["state"] = "paused"; rows[i]["note"] = "Подготовка прервана. Можно повторить."
        }
    }
    private func save() {
        guard !owner.isEmpty else { return }
        try? manager.createDirectory(at: directory, withIntermediateDirectories: true)
        if let data = try? JSONSerialization.data(withJSONObject: ["schema": 1, "owner": owner, "items": rows]) {
            try? data.write(to: directory.appendingPathComponent("index.json"), options: .atomic)
        }
        NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
    }
    func file(_ row: JSON) -> URL? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        let url = directory.appendingPathComponent(key + ".mp4")
        guard let attrs = try? manager.attributesOfItem(atPath: url.path),
            let size = attrs[.size] as? NSNumber, size.int64Value > 0,
            size.int64Value == (row["bytes"] as? NSNumber)?.int64Value else { return nil }
        return url
    }
    func remove(_ key: String) {
        guard let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
        let scope = owner
        session.getAllTasks { tasks in tasks.filter { $0.taskDescription == scope + "|" + key }.forEach { $0.cancel() } }
        let url = directory.appendingPathComponent(key + ".mp4")
        try? manager.removeItem(at: url); try? manager.removeItem(at: directory.appendingPathComponent(key + ".resume"))
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".jpg"))
        if owner == scope { rows.remove(at: i); save() }
    }
    func position(_ key: String, seconds: Double) {
        guard seconds.isFinite, let i = rows.firstIndex(where: { string($0["key"]) == key }) else { return }
        rows[i]["position"] = max(0, seconds); save()
    }
    func pause(_ key: String) {
        if let i = rows.firstIndex(where: { string($0["key"]) == key && string($0["state"]) == "preparing" }) {
            preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
            rows[i]["state"] = "paused"; rows[i]["note"] = "Ожидание приостановлено. Можно продолжить."; save(); return
        }
        let scope = owner; let folder = directory
        session.getAllTasks { tasks in
            for task in tasks where task.taskDescription == scope + "|" + key {
                (task as? URLSessionDownloadTask)?.cancel(byProducingResumeData: { data in DispatchQueue.main.async {
                    guard self.owner == scope, let i = self.rows.firstIndex(where: { string($0["key"]) == key &&
                        ($0["task_id"] == nil || Int(number($0["task_id"])) == task.taskIdentifier) }) else { return }
                    if let data = data { try? data.write(to: folder.appendingPathComponent(key + ".resume"), options: .atomic) }
                    self.rows[i]["state"] = "paused"; self.rows[i]["note"] = "Приостановлено"; self.save()
                }})
            }
        }
    }
    private func checkSlot(except key: String) throws {
        guard !rows.contains(where: { string($0["key"]) != key && DownloadDisplay.isActive($0) }) else {
            throw failure("На этом iPad загружаем по одному файлу. Дождитесь окончания или приостановите загрузку.")
        }
    }
    func prepare(_ movie: Movie, choice: String, context: String) throws {
        guard !owner.isEmpty, AppDelegate.current.authenticated, !choice.isEmpty,
            let key = DownloadDisplay.key(movie, context: context) else { throw failure("Для загрузки нужен вход и выбранная серия.") }
        try checkSlot(except: key)
        if let old = rows.first(where: { string($0["key"]) == key }),
            DownloadDisplay.isActive(old) || string(old["state"]) == "ready" { throw failure("Этот файл уже есть в загрузках.") }
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)?.cancel()
        let i: Int
        if let old = rows.firstIndex(where: { string($0["key"]) == key }) { i = old }
        else { rows.append(["key": key]); i = rows.count - 1 }
        rows[i]["movie"] = movie.display; rows[i]["context"] = context; rows[i]["state"] = "preparing"
        // A newly selected source must never resume bytes from the previous source.
        try? manager.removeItem(at: directory.appendingPathComponent(key + ".resume"))
        rows[i].removeValue(forKey: "ref"); rows[i].removeValue(forKey: "preparation_percent")
        rows[i]["phase"] = "register"; rows[i]["note"] = "Ставим в очередь подготовки…"
        let token = UUID(), scope = owner; preparations[key] = token
        savePoster(movie, key: key); save()
        preparationRequests[key] = API.shared.call("api/device-queue", method: "POST", body: ["action": "register", "choice": choice,
            "download_mode": "compatible", "capabilities": []]) { [weak self] value, error in
            guard let self = self, let current = self.preparationIndex(key, token: token, scope: scope) else { return }
            self.preparationRequests.removeValue(forKey: key)
            if let error = error { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription); return }
            let ref = string(value?["ref"])
            guard !ref.isEmpty else { self.preparationFailed(key, token: token, scope: scope, note: "Не удалось создать загрузку."); return }
            self.rows[current]["ref"] = ref; self.save()
            self.resolve(key, token: token, scope: scope, until: Date().addingTimeInterval(4 * 3600))
        }
    }
    private func preparationIndex(_ key: String, token: UUID, scope: String) -> Int? {
        guard owner == scope, preparations[key] == token else { return nil }
        return rows.firstIndex { string($0["key"]) == key && string($0["state"]) == "preparing" }
    }
    private func preparationFailed(_ key: String, token: UUID, scope: String, note: String) {
        guard let i = preparationIndex(key, token: token, scope: scope) else { return }
        preparations.removeValue(forKey: key); preparationRequests.removeValue(forKey: key)
        rows[i]["state"] = "paused"; rows[i]["note"] = note + " Можно продолжить."; save()
    }
    func resumePreparation(_ key: String) throws {
        guard AppDelegate.current.authenticated, let i = rows.firstIndex(where: { string($0["key"]) == key }),
            !string(rows[i]["ref"]).isEmpty else { throw failure("Для продолжения нужен интернет и вход в Медиатеку.") }
        guard !DownloadDisplay.isActive(rows[i]), string(rows[i]["state"]) != "ready" else { return }
        try checkSlot(except: key)
        let token = UUID(); preparations[key] = token
        rows[i]["state"] = "preparing"; rows[i]["note"] = "Проверяем подготовку…"; save()
        resolve(key, token: token, scope: owner, until: Date().addingTimeInterval(4 * 3600), retry: true)
    }
    private func resolve(_ key: String, token: UUID, scope: String, until: Date, retry: Bool = false) {
        guard let i = preparationIndex(key, token: token, scope: scope) else { return }
        guard Date() < until else { preparationFailed(key, token: token, scope: scope, note: "Подготовка заняла слишком много времени."); return }
        // Preparation belongs to the store, not a screen. Resume polling when the app is foregrounded.
        if UIApplication.shared.applicationState != .active {
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in self?.resolve(key, token: token, scope: scope, until: until, retry: retry) }; return
        }
        preparationRequests[key] = API.shared.call("api/device-queue", method: "POST", body: ["action": "resolve", "ref": string(rows[i]["ref"]),
            "retry": retry], timeout: 140) { [weak self] value, error in
            guard let self = self, let current = self.preparationIndex(key, token: token, scope: scope) else { return }
            self.preparationRequests.removeValue(forKey: key)
            if let error = error { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription); return }
            guard let value = value else { self.preparationFailed(key, token: token, scope: scope, note: "Сервер вернул пустой ответ."); return }
            if value["pending"] as? Bool == true {
                self.rows[current]["phase"] = string(value["phase"])
                self.rows[current]["note"] = string(value["note"])
                self.rows[current]["preparation_percent"] = value["preparation_percent"]
                self.save()
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in self?.resolve(key, token: token, scope: scope, until: until) }; return
            }
            do {
                guard let movie = Movie(self.rows[current]["movie"] as? JSON ?? [:]) else { throw failure("Карточка недоступна.") }
                try self.enqueue(movie, links: value, context: string(self.rows[current]["context"]))
                self.preparations.removeValue(forKey: key)
            } catch { self.preparationFailed(key, token: token, scope: scope, note: error.localizedDescription) }
        }
    }
    private func enqueue(_ movie: Movie, links: JSON, context: String) throws {
        guard !owner.isEmpty, let url = Config.mediaURL(string(links["download_url"])) else { throw failure("Адрес загрузки недоступен.") }
        let bytes = Int64(number(links["file_size"]))
        guard bytes > 0, bytes <= Config.maxFileBytes else { throw failure("Сервер не сообщил допустимый размер файла.") }
        let free = ((try? manager.attributesOfFileSystem(forPath: root.path)[.systemFreeSize]) as? NSNumber)?.int64Value ?? 0
        guard free > bytes + Config.reserveBytes else { throw failure("Недостаточно свободного места. Удалите другие загрузки.") }
        guard let identity = DownloadDisplay.key(movie, context: context) else { throw failure("Не удалось определить серию.") }
        try checkSlot(except: identity)
        let i: Int
        if let old = rows.firstIndex(where: { string($0["key"]) == identity }) {
            guard string(rows[old]["state"]) != "ready" else { throw failure("Этот файл уже доступен офлайн.") }; i = old
        } else { rows.append(["key": identity, "movie": movie.display, "context": context]); i = rows.count - 1 }
        rows[i]["state"] = "downloading"; rows[i]["bytes"] = bytes; rows[i]["received"] = 0
        rows[i]["note"] = "Загрузка по Wi-Fi"
        let resumeURL = directory.appendingPathComponent(identity + ".resume")
        let task: URLSessionDownloadTask
        if let resume = try? Data(contentsOf: resumeURL) {
            // Signed server URLs can expire. A failed resume is retryable via a newly resolved URL.
            task = session.downloadTask(withResumeData: resume); try? manager.removeItem(at: resumeURL)
        } else {
            var request = URLRequest(url: url)
            Config.requestHeaders.forEach { request.setValue($0.value, forHTTPHeaderField: $0.key) }
            request.setValue("video/mp4", forHTTPHeaderField: "Accept")
            task = session.downloadTask(with: request)
        }
        task.taskDescription = owner + "|" + identity
        rows[i]["task_id"] = task.taskIdentifier; save(); task.resume()
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64,
                    totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let i = index(downloadTask) else { return }
        rows[i]["received"] = totalBytesWritten
        if Date().timeIntervalSince(lastSave) > 2 { lastSave = Date(); save() }
    }
    private func index(_ task: URLSessionTask) -> Int? {
        guard let description = task.taskDescription, description.hasPrefix(owner + "|") else { return nil }
        let key = String(description.dropFirst(owner.count + 1))
        return rows.firstIndex { string($0["key"]) == key && string($0["state"]) == "downloading" &&
            ($0["task_id"] == nil || Int(number($0["task_id"])) == task.taskIdentifier) }
    }
    func poster(_ row: JSON) -> UIImage? {
        let key = string(row["key"])
        guard key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) != nil else { return nil }
        return UIImage(contentsOfFile: directory.appendingPathComponent(key + ".jpg").path)
    }
    private func savePoster(_ movie: Movie, key: String) {
        let scope = owner; let destination = directory.appendingPathComponent(key + ".jpg")
        // A local title card is always present, even if the remote poster is unavailable.
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 300, height: 450), true, 1)
        Theme.panel.setFill(); UIRectFill(CGRect(x: 0, y: 0, width: 300, height: 450))
        let attributes: [NSAttributedString.Key: Any] = [.font: UIFont.boldSystemFont(ofSize: 25), .foregroundColor: UIColor.white]
        (movie.title as NSString).draw(in: CGRect(x: 22, y: 160, width: 256, height: 220), withAttributes: attributes)
        let placeholder = UIGraphicsGetImageFromCurrentImageContext(); UIGraphicsEndImageContext()
        if let data = placeholder?.jpegData(compressionQuality: 0.8) { try? data.write(to: destination, options: .atomic) }
        guard let url = Config.mediaURL(movie.poster), !movie.poster.isEmpty else { return }
        URLSession.shared.dataTask(with: url) { data, response, _ in
            guard (response as? HTTPURLResponse)?.statusCode == 200, let data = data, data.count <= 2 * 1024 * 1024,
                let source = CGImageSourceCreateWithData(data as CFData, nil),
                let bitmap = CGImageSourceCreateThumbnailAtIndex(source, 0,
                    [kCGImageSourceCreateThumbnailFromImageAlways: true, kCGImageSourceThumbnailMaxPixelSize: 600,
                     kCGImageSourceCreateThumbnailWithTransform: true] as CFDictionary) else { return }
            let image = UIImage(cgImage: bitmap)
            DispatchQueue.main.async {
                guard self.owner == scope, self.rows.contains(where: { string($0["key"]) == key }),
                    let data = image.jpegData(compressionQuality: 0.85) else { return }
                try? data.write(to: destination, options: .atomic)
                NotificationCenter.default.post(name: OfflineStore.changed, object: nil)
            }
        }.resume()
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let i = index(downloadTask) else { return }
        let key = string(rows[i]["key"]); let scope = owner
        do {
            guard let response = downloadTask.response as? HTTPURLResponse, response.statusCode == 200,
                response.url.map({ Config.trusted($0) }) == true else { throw failure("Сервер отклонил загрузку. Повторите подготовку файла.") }
            let size = ((try manager.attributesOfItem(atPath: location.path))[.size] as? NSNumber)?.int64Value ?? 0
            guard size == Int64(number(rows[i]["bytes"])) else { throw failure("Файл получен не полностью.") }
            let destination = directory.appendingPathComponent(key + ".mp4")
            try? manager.removeItem(at: destination); try manager.moveItem(at: location, to: destination)
            try manager.setAttributes([.protectionKey: FileProtectionType.completeUntilFirstUserAuthentication], ofItemAtPath: destination.path)
            rows[i]["state"] = "verifying"; rows[i]["note"] = "Проверяем видео"; save()
            let asset = AVURLAsset(url: destination)
            asset.loadValuesAsynchronously(forKeys: ["playable", "tracks", "duration"]) { DispatchQueue.main.async {
                guard self.owner == scope, let current = self.rows.firstIndex(where: { string($0["key"]) == key &&
                    string($0["state"]) == "verifying" && Int(number($0["task_id"])) == downloadTask.taskIdentifier }) else { return }
                var error: NSError?
                let loaded = ["playable", "tracks", "duration"].allSatisfy { asset.statusOfValue(forKey: $0, error: &error) == .loaded }
                let video = asset.tracks(withMediaType: .video).first
                let descriptions = video?.formatDescriptions as? [CMFormatDescription] ?? []
                let h264 = descriptions.contains { CMFormatDescriptionGetMediaSubType($0) == kCMVideoCodecType_H264 }
                let aac = asset.tracks(withMediaType: .audio).allSatisfy { track in
                    let formats = track.formatDescriptions as? [CMFormatDescription] ?? []
                    return !formats.isEmpty && formats.allSatisfy { format in
                        guard let audio = CMAudioFormatDescriptionGetStreamBasicDescription(format)?.pointee else { return false }
                        return audio.mFormatID == kAudioFormatMPEG4AAC && audio.mChannelsPerFrame <= 2 && audio.mSampleRate <= 48000
                    }
                }
                let dimensions = video.map { $0.naturalSize.applying($0.preferredTransform) } ?? .zero
                let allowed = max(abs(dimensions.width), abs(dimensions.height)) <= 1920 && min(abs(dimensions.width), abs(dimensions.height)) <= 1080
                guard loaded, asset.isPlayable, h264, aac, allowed, (video?.nominalFrameRate ?? 0) <= 60, CMTimeGetSeconds(asset.duration).isFinite,
                    CMTimeGetSeconds(asset.duration) > 0 else {
                    try? self.manager.removeItem(at: destination)
                    self.rows[current]["state"] = "error"; self.rows[current]["note"] = "Файл не подходит этому iPad. Выберите другую раздачу H.264 до Full HD."
                    self.save(); return
                }
                self.rows[current]["state"] = "ready"; self.rows[current]["note"] = "Доступно без интернета"
                self.rows[current]["received"] = size; self.rows[current]["duration"] = CMTimeGetSeconds(asset.duration); self.save()
            }}
        } catch { rows[i]["state"] = "error"; rows[i]["note"] = error.localizedDescription; save() }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error as NSError?, let i = index(task) else { return }
        if let data = error.userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
            try? data.write(to: directory.appendingPathComponent(string(rows[i]["key"]) + ".resume"), options: .atomic)
        }
        rows[i]["state"] = "paused"; rows[i]["note"] = "Загрузка прервана. Можно продолжить."; save()
    }
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async { let done = self.backgroundCompletion; self.backgroundCompletion = nil; done?() }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(request.url.map { Config.trusted($0) } == true ? request : nil)
    }
}
