#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
# An unsigned bundle is a build artifact, not an installable signed distribution.
VERSION="$(xcodebuild -version | head -n 1)"
if [[ "$VERSION" != "Xcode 13.4.1" ]]; then
  echo "Нужен Xcode 13.4.1. Текущая среда: $VERSION" >&2; exit 2
fi
python3 generate_project.py
python3 tests/check_project.py
mkdir -p build
xcrun swiftc -swift-version 5 MediatekaLite/Config.swift tests/main.swift -o build/model-tests
build/model-tests
xcodebuild -project MediatekaLite.xcodeproj -scheme MediatekaLite -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO ARCHS=arm64 ONLY_ACTIVE_ARCH=NO \
  IPHONEOS_DEPLOYMENT_TARGET=10.0 build
APP="build/Build/Products/Release-iphoneos/MediatekaLite.app"
test -f "$APP/MediatekaLite"
/usr/libexec/PlistBuddy -c 'Print :MinimumOSVersion' "$APP/Info.plist" | grep -x '10.0'
xcrun lipo "$APP/MediatekaLite" -verify_arch arm64
python3 tests/check_binary.py "$APP"
mkdir -p build/package/Payload
ditto "$APP" build/package/Payload/MediatekaLite.app
(cd build/package && /usr/bin/zip -qry ../MediatekaLite-0.1-ios10-unsigned.ipa Payload)
shasum -a 256 build/MediatekaLite-0.1-ios10-unsigned.ipa
# Separate artifact for an already jailbroken device with AppSync installed.
# No Apple credentials or provisioning profiles are used by ad-hoc signing.
mkdir -p build/appsync/Payload
ditto "$APP" build/appsync/Payload/MediatekaLite.app
JBAPP="build/appsync/Payload/MediatekaLite.app"
for library in "$JBAPP"/Frameworks/*.dylib; do
  /usr/bin/codesign --force --sign - --timestamp=none --digest-algorithm=sha1,sha256 "$library"
done
/usr/bin/codesign --force --sign - --timestamp=none --digest-algorithm=sha1,sha256 \
  --entitlements MediatekaLite/AppSync.entitlements.plist "$JBAPP"
/usr/bin/codesign --verify --deep --strict "$JBAPP"
(cd build/appsync && /usr/bin/zip -qry ../MediatekaLite-0.1.2-ios10-AppSync-build4.ipa Payload)
shasum -a 256 build/MediatekaLite-0.1.2-ios10-AppSync-build4.ipa
echo 'AppSync artifact requires an active jailbreak. Unsigned artifact still requires signing. Verify launch and login on the physical iPad.'
