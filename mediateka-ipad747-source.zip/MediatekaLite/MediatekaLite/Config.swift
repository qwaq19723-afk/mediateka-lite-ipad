import Foundation

enum Config {
    static let base = URL(string: "https://panelfreak.zyxcloud.xyz/mediabot/")!
    static let bundle = "xyz.zyxcloud.mediateka.lite"
    static let origin = "https://panelfreak.zyxcloud.xyz"
    static let requestHeaders = ["User-Agent": "MediatekaLite/0.1.3 iPad iOS10",
        "Origin": origin, "Referer": base.absoluteString,
        "X-Mediateka-Device718": "mobile", "X-Mediateka-Max-Height": "720", "Accept": "application/json"]
    static let maxVideoWidth = 1280
    static let maxVideoHeight = 720
    static let maxFileBytes: Int64 = 8_000_000_000
    static let reserveBytes: Int64 = 512 * 1024 * 1024
    static func trusted(_ url: URL) -> Bool {
        return url.scheme == "https" && url.host == base.host && url.port == nil &&
            url.user == nil && url.password == nil && url.path.hasPrefix(base.path) &&
            !url.pathComponents.contains("..") && !url.pathComponents.contains(".") &&
            !(URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedPath.lowercased().contains("%2f") ?? true) &&
            !url.path.contains("\\")
    }
    static func mediaURL(_ value: String) -> URL? {
        guard let url = URL(string: value, relativeTo: base)?.absoluteURL, trusted(url) else { return nil }
        return url
    }
}

typealias JSON = [String: Any]
func string(_ value: Any?) -> String {
    if let text = value as? String { return text }
    if let number = value as? NSNumber { return number.stringValue }
    return ""
}
func number(_ value: Any?) -> Double {
    let result = (value as? NSNumber)?.doubleValue ?? Double(string(value)) ?? 0
    return result.isFinite && abs(result) < 1e15 ? result : 0
}
func failure(_ text: String) -> NSError { return NSError(domain: Config.bundle, code: 1, userInfo: [NSLocalizedDescriptionKey: text]) }

struct SessionSnapshot {
    let reachable: Bool
    let authenticated: Bool
    let owner: String
    let message: String
    init(_ value: JSON?, error: Error?) {
        if let signedIn = value?["authenticated"] as? Bool {
            reachable = true
            let user = value?["user"] as? JSON ?? [:]
            owner = signedIn ? string(user["id"] ?? user["user_id"]) : ""
            authenticated = signedIn && !owner.isEmpty
            message = authenticated ? "Подключено к Медиатеке." :
                (string(value?["reason"]) == "access" ? "Для этого аккаунта доступ закрыт. Войдите другим аккаунтом." :
                "Интернет доступен. Войдите через Telegram для открытия каталога.")
        } else {
            reachable = false; authenticated = false; owner = ""
            let issue = error as NSError?
            if issue?.domain == NSURLErrorDomain && [-1200, -1201, -1202, -1203, -1204].contains(issue?.code ?? 0) {
                message = "Не удалось проверить защищённое соединение. Проверьте дату и время iPad."
            } else if issue?.domain == NSURLErrorDomain && issue?.code == NSURLErrorNotConnectedToInternet {
                message = "Нет подключения к интернету. Скачанное доступно офлайн."
            } else {
                message = "Нет связи с Медиатекой. Нажмите «Проверить связь»."
            }
        }
    }
}

struct Movie {
    let id: String
    let kind: String
    let title: String
    let year: String
    let overview: String
    let poster: String
    let raw: JSON
    init?(_ json: JSON) {
        let id = string(json["id"] ?? json["tmdb_id"])
        guard !id.isEmpty, id.range(of: "^[0-9]+$", options: .regularExpression) != nil else { return nil }
        self.id = id
        let kind = string(json["kind"] ?? json["media_type"])
        self.kind = kind == "tv" || kind == "series" ? "tv" : "movie"
        title = string(json["title"] ?? json["name"])
        year = string(json["year"])
        overview = string(json["overview"] ?? json["description"] ?? json["plot"])
        poster = string(json["cover"] ?? json["poster"])
        raw = json
    }
    var key: String { return kind + "-" + id }
    // Persist display metadata only. Owner-bound choices/tickets are renewed online.
    var display: JSON { return ["id": id, "kind": kind, "title": title, "year": year, "overview": overview, "cover": poster] }
}

enum DownloadDisplay {
    static func isActive(_ row: JSON) -> Bool {
        return ["preparing", "downloading", "verifying"].contains(string(row["state"]))
    }
    static func key(_ movie: Movie, context: String) -> String? {
        let key = movie.key + (context.isEmpty ? "" : "-" + context)
        return key.range(of: "^[a-zA-Z0-9-]{1,100}$", options: .regularExpression) == nil ? nil : key
    }
    static func note(_ row: JSON) -> String {
        switch string(row["state"]) {
        case "preparing":
            let phase = string(row["phase"])
            let label = phase == "staging" ? "Подготовка на сервере" : phase == "verify" ? "Проверка MP4" : "Подготовка MP4"
            return label + (row["preparation_percent"] == nil ? "…" : " · \(Int(max(0, min(99, number(row["preparation_percent"])))))%")
        case "downloading":
            let bytes = number(row["bytes"]), received = max(0, number(row["received"]))
            let amount = ByteCountFormatter.string(fromByteCount: Int64(received), countStyle: .file)
            guard bytes > 0 else { return "Скачивание · " + amount }
            return "\(Int(min(100, received / bytes * 100)))% · " + amount + " / " + ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
        case "verifying": return "Проверяем видео на iPad…"
        case "ready":
            if number(row["position"]) > 0 { return "Продолжить с \(Int(number(row["position"]) / 60)) мин" }
            return "Доступно без интернета"
        default: return string(row["note"])
        }
    }
    static func fraction(_ row: JSON) -> Float? {
        if string(row["state"]) == "preparing", row["preparation_percent"] != nil {
            return Float(max(0, min(99, number(row["preparation_percent"]))) / 100)
        }
        if string(row["state"]) == "downloading", number(row["bytes"]) > 0 {
            return Float(max(0, min(1, number(row["received"]) / number(row["bytes"]))))
        }
        return nil
    }
}

enum CatalogSection {
    static func path(series: Bool, popular: Bool, page: Int) -> String {
        let section = (popular ? "popular-" : "new-") + (series ? "series" : "movies")
        return "api/atv/launcher480?section=" + section + "&page=\(page)"
    }
}

enum VideoQuality {
    static func dimensionsAllowed(width: Double, height: Double) -> Bool {
        return width.isFinite && height.isFinite && width > 0 && height > 0 &&
            max(width, height) <= Double(Config.maxVideoWidth) && min(width, height) <= Double(Config.maxVideoHeight)
    }
    // Catalogue hints can be missing; the server probe and player enforce the final dimensions.
    static func hintAllowed(_ value: JSON) -> Bool {
        let release = value["release542"] as? JSON ?? [:]
        let candidates = [value, value["source558"] as? JSON ?? [:], release,
            release["source558"] as? JSON ?? [:], value["device_work"] as? JSON ?? [:]]
        for metadata in candidates {
            let width = number(metadata["width"]), height = number(metadata["height"])
            if width > Double(Config.maxVideoWidth) || height > Double(Config.maxVideoHeight) { return false }
            let sourceWidth = number(metadata["source_width"]), sourceHeight = number(metadata["source_height"])
            if sourceWidth > Double(Config.maxVideoWidth) || sourceHeight > Double(Config.maxVideoHeight) { return false }
            let title = string(metadata["title"] ?? metadata["name"]).lowercased()
            if title.range(of: "(?<![a-z0-9])(?:1080[pi]?|1440[pi]?|2160[pi]?|4320[pi]?|4k|8k|uhd)(?![a-z0-9])", options: .regularExpression) != nil { return false }
            if title.range(of: "hevc|x265|h[ ._-]?265", options: .regularExpression) != nil { return false }
            if let match = title.range(of: "[0-9]{2,5}\\s*[xх×]\\s*[0-9]{2,5}", options: .regularExpression) {
                let dimensions = title[match].components(separatedBy: CharacterSet.decimalDigits.inverted).filter { !$0.isEmpty }.compactMap(Double.init)
                if dimensions.count == 2 && !dimensionsAllowed(width: dimensions[0], height: dimensions[1]) { return false }
            }
        }
        return true
    }
}
